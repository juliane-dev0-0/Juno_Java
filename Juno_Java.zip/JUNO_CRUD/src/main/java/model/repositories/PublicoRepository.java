package model.repositories;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dao.BasicCrud;
import model.entities.Publico;

// vai interagir com o banco 

public class PublicoRepository implements BasicCrud {
	private EntityManager em;

	public PublicoRepository() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("junoVersaoFinal");
		this.em = emf.createEntityManager();
	}

	@Override
	public Object create(Object object) {
		Publico publico = (Publico) object;
		try {
			em.getTransaction().begin();
			em.persist(publico);
			em.getTransaction().commit();
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return publico;
	}

	@Override
	public Object findById(Long id) {
		try {
			return em.find(Publico.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object updateById(Object object) {
		Publico publicoUpdate = (Publico) object;
		em.getTransaction().begin();
		em.merge(publicoUpdate);
		em.getTransaction().commit();
		return publicoUpdate;
	}

	@Override
	public void delete(Long id) {
		em.getTransaction().begin();
		var publico = (Publico) findById(id);
		if (publico != null) {
			em.remove(publico);
		}
		em.getTransaction().commit();
	}

	public List<Publico> findAll() {
		Query query = em.createQuery("SELECT pc FROM Publico pc", Publico.class);
		return query.getResultList();
	}
}
