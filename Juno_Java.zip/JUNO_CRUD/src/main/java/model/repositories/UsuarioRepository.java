package model.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dao.BasicCrud;
import model.entities.Usuario;

// vai interagir com o banco 

public class UsuarioRepository implements BasicCrud {
	private EntityManager em;

	public UsuarioRepository() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("junoVersaoFinal");
		this.em = emf.createEntityManager();
	}

	@Override
	public Object create(Object object) {
		Usuario usuario = (Usuario) object;
		// se o email n estiver sendo usado
		em.getTransaction().begin();
		em.persist(usuario);
		em.getTransaction().commit();
		return usuario;
	}

	// consulta o banco e verifica se o email ja foi cadastrado
	public boolean isEmailInUse(String email) {
		// Consultar o banco de dados para verificar se o e-mail já está em uso
		Query query = em.createQuery("SELECT COUNT(u) FROM Usuario u WHERE u.email = :email", Long.class);
		query.setParameter("email", email);
		Long count = (Long) query.getSingleResult();
		return count > 0;
	}

	@Override
	public Object findById(Long id) {
		try {
			return em.find(Usuario.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object updateById(Object object) {
		Usuario usuarioUpdate = (Usuario) object;
		em.getTransaction().begin();
		em.merge(usuarioUpdate);
		em.getTransaction().commit();
		return usuarioUpdate;
	}

	@Override
	public void delete(Long id) {
		em.getTransaction().begin();
		var usuario = (Usuario) findById(id);
		if (usuario != null) {
			em.remove(usuario);
		}
		em.getTransaction().commit();
	}

	public List<Usuario> findAll() {
		Query query = em.createQuery("SELECT u FROM Usuario u", Usuario.class);
		return query.getResultList();
	}

	public Usuario findByEmailAndSenha(String email, String senha) {
		try {
			Query query = em.createQuery("SELECT u FROM Usuario u WHERE u.email = :email AND u.senha = :senha",
					Usuario.class);
			query.setParameter("email", email);
			query.setParameter("senha", senha);
			return (Usuario) query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

}
