package model.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dao.BasicCrud;
import model.entities.Paciente;

// vai interagir com o banco 

public class PacienteRepository implements BasicCrud {
	private EntityManager em;

	public PacienteRepository() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("junoVersaoFinal");
		this.em = emf.createEntityManager();
	}

	@Override
	public Object create(Object object) {
		Paciente paciente = (Paciente) object;
		try {
			em.getTransaction().begin();
			em.persist(paciente);
			em.getTransaction().commit();
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return paciente;
	}

	@Override
	public Object findById(Long id) {
		try {
			return em.find(Paciente.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object updateById(Object object) {
		Paciente pacienteUpdate = (Paciente) object;
		em.getTransaction().begin();
		em.merge(pacienteUpdate);
		em.getTransaction().commit();
		return pacienteUpdate;
	}

	@Override
	public void delete(Long id) {
		em.getTransaction().begin();
		var paciente = (Paciente) findById(id);
		if (paciente != null) {
			em.remove(paciente);
		}
		em.getTransaction().commit();
	}

	public List<Paciente> findAll() {
		Query query = em.createQuery("SELECT p FROM Paciente p", Paciente.class);
		return query.getResultList();
	}

	public Paciente findByName(String nome) {
		try {
			return em.createQuery("SELECT p FROM Paciente p WHERE p.nome = :nome", Paciente.class)
					.setParameter("nome", nome).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

}
