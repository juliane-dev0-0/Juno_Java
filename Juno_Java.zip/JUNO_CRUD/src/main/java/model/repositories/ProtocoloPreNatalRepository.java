package model.repositories;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dao.BasicCrud;
import model.entities.ProtocoloPreNatal;

// vai interagir com o banco 

public class ProtocoloPreNatalRepository implements BasicCrud {
	private EntityManager em;

	public ProtocoloPreNatalRepository() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("junoVersaoFinal");
		this.em = emf.createEntityManager();
	}

	@Override
	public Object create(Object object) {
		ProtocoloPreNatal protocoloPreNatal = (ProtocoloPreNatal) object;
		try {
			em.getTransaction().begin();
			em.persist(protocoloPreNatal);
			em.getTransaction().commit();
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return protocoloPreNatal;
	}

	@Override
	public Object findById(Long id) {
		try {
			return em.find(ProtocoloPreNatal.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object updateById(Object object) {
		ProtocoloPreNatal protocoloPreNatalUpdate = (ProtocoloPreNatal) object;
		em.getTransaction().begin();
		em.merge(protocoloPreNatalUpdate);
		em.getTransaction().commit();
		return protocoloPreNatalUpdate;
	}

	@Override
	public void delete(Long id) {
		em.getTransaction().begin();
		var protocoloPreNatal = (ProtocoloPreNatal) findById(id);
		if (protocoloPreNatal != null) {
			em.remove(protocoloPreNatal);
		}
		em.getTransaction().commit();
	}

	public List<ProtocoloPreNatal> findAll() {
		Query query = em.createQuery("SELECT proto FROM ProtocoloPreNatal proto", ProtocoloPreNatal.class);
		return query.getResultList();
	}
}
