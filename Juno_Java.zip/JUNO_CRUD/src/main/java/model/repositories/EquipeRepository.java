package model.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dao.BasicCrud;
import model.entities.Equipe;

// vai interagir com o banco 

public class EquipeRepository implements BasicCrud {
	private EntityManager em;

	public EquipeRepository() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("junoVersaoFinal");
		this.em = emf.createEntityManager();
	}

	@Override
	public Object create(Object object) {
		Equipe equipe = (Equipe) object;
		try {
			em.getTransaction().begin();
			em.persist(equipe);
			em.getTransaction().commit();
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return equipe;
	}

	@Override
	public Object findById(Long id) {
		try {
			return em.find(Equipe.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object updateById(Object object) {
		Equipe equipeUpdate = (Equipe) object;
		em.getTransaction().begin();
		em.merge(equipeUpdate);
		em.getTransaction().commit();
		return equipeUpdate;
	}

	@Override
	public void delete(Long id) {
		em.getTransaction().begin();
		var equipe = (Equipe) findById(id);
		if (equipe != null) {
			em.remove(equipe);
		}
		em.getTransaction().commit();
	}

	public List<Equipe> findAll() {
		Query query = em.createQuery("SELECT e FROM Equipe e", Equipe.class);
		return query.getResultList();
	}
}
