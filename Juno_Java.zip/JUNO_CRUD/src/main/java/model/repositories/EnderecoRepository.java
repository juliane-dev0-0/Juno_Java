package model.repositories;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dao.BasicCrud;
import model.entities.Endereco;

// vai interagir com o banco 

public class EnderecoRepository implements BasicCrud {
	private EntityManager em;

	public EnderecoRepository() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("junoVersaoFinal");
		this.em = emf.createEntityManager();
	}

	@Override
	public Object create(Object object) {
		Endereco endereco = (Endereco) object;
		try {
			em.getTransaction().begin();
			em.persist(endereco);
			em.getTransaction().commit();
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return endereco;
	}

	@Override
	public Object findById(Long id) {
		try {
			return em.find(Endereco.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object updateById(Object object) {
		Endereco enderecoUpdate = (Endereco) object;
		em.getTransaction().begin();
		em.merge(enderecoUpdate);
		em.getTransaction().commit();
		return enderecoUpdate;
	}

	@Override
	public void delete(Long id) {
		em.getTransaction().begin();
		var endereco = (Endereco) findById(id);
		if (endereco != null) {
			em.remove(endereco);
		}
		em.getTransaction().commit();
	}

	public List<Endereco> findAll() {
		Query query = em.createQuery("SELECT e FROM Endereco e", Endereco.class);
		return query.getResultList();
	}
}
