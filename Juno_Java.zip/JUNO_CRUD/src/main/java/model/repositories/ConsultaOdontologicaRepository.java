package model.repositories;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dao.BasicCrud;
import model.entities.ConsultaOdontologica;

// vai interagir com o banco 

public class ConsultaOdontologicaRepository implements BasicCrud {
	private EntityManager em;

	public ConsultaOdontologicaRepository() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("junoVersaoFinal");
		this.em = emf.createEntityManager();
	}

	@Override
	public Object create(Object object) {
		ConsultaOdontologica consultaOdontologica = (ConsultaOdontologica) object;
		try {
			em.getTransaction().begin();
			em.persist(consultaOdontologica);
			em.getTransaction().commit();
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return consultaOdontologica;
	}

	@Override
	public Object findById(Long id) {
		try {
			return em.find(ConsultaOdontologica.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object updateById(Object object) {
		ConsultaOdontologica consultaOdontologicaUpdate = (ConsultaOdontologica) object;
		em.getTransaction().begin();
		em.merge(consultaOdontologicaUpdate);
		em.getTransaction().commit();
		return consultaOdontologicaUpdate;
	}

	@Override
	public void delete(Long id) {
		em.getTransaction().begin();
		var consultaOdontologica = (ConsultaOdontologica) findById(id);
		if (consultaOdontologica != null) {
			em.remove(consultaOdontologica);
		}
		em.getTransaction().commit();
	}

	public List<ConsultaOdontologica> findAll() {
		Query query = em.createQuery("SELECT co FROM ConsultaOdontologica co", ConsultaOdontologica.class);
		return query.getResultList();
	}
}
