package model.repositories;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dao.BasicCrud;
import model.entities.Conta;

// vai interagir com o banco 

public class ContaRepository implements BasicCrud {
	private EntityManager em;

	public ContaRepository() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("junoVersaoFinal");
		this.em = emf.createEntityManager();
	}

	@Override
	public Object create(Object object) {
		Conta conta = (Conta) object;
		try {
			em.getTransaction().begin();
			em.persist(conta);
			em.getTransaction().commit();
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return conta;
	}

	@Override
	public Object findById(Long id) {
		try {
			return em.find(Conta.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object updateById(Object object) {
		Conta contaUpdate = (Conta) object;
		em.getTransaction().begin();
		em.merge(contaUpdate);
		em.getTransaction().commit();
		return contaUpdate;
	}

	@Override
	public void delete(Long id) {
		em.getTransaction().begin();
		var conta = (Conta) findById(id);
		if (conta != null) {
			em.remove(conta);
		}
		em.getTransaction().commit();
	}

	public List<Conta> findAll() {
		Query query = em.createQuery("SELECT c FROM Conta c", Conta.class);
		return query.getResultList();
	}

}
