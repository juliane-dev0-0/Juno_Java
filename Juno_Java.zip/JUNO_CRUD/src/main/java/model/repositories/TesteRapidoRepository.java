package model.repositories;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dao.BasicCrud;
import model.entities.TesteRapido;

// vai interagir com o banco 

public class TesteRapidoRepository implements BasicCrud {
	private EntityManager em;

	public TesteRapidoRepository() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("junoVersaoFinal");
		this.em = emf.createEntityManager();
	}

	@Override
	public Object create(Object object) {
		TesteRapido testeRapido = (TesteRapido) object;
		try {
			em.getTransaction().begin();
			em.persist(testeRapido);
			em.getTransaction().commit();
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return testeRapido;
	}

	@Override
	public Object findById(Long id) {
		try {
			return em.find(TesteRapido.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object updateById(Object object) {
		TesteRapido testeRapidoUpdate = (TesteRapido) object;
		em.getTransaction().begin();
		em.merge(testeRapidoUpdate);
		em.getTransaction().commit();
		return testeRapidoUpdate;
	}

	@Override
	public void delete(Long id) {
		em.getTransaction().begin();
		var testeRapido = (TesteRapido) findById(id);
		if (testeRapido != null) {
			em.remove(testeRapido);
		}
		em.getTransaction().commit();
	}

	public List<TesteRapido> findAll() {
		Query query = em.createQuery("SELECT tr FROM TesteRapido tr", TesteRapido.class);
		return query.getResultList();
	}
}
