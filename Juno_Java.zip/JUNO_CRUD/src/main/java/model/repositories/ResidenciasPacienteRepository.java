package model.repositories;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dao.BasicCrud;
import model.entities.ResidenciasPaciente;

// vai interagir com o banco 

public class ResidenciasPacienteRepository implements BasicCrud {
	private EntityManager em;

	public ResidenciasPacienteRepository() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("junoVersaoFinal");
		this.em = emf.createEntityManager();
	}

	@Override
	public Object create(Object object) {
		ResidenciasPaciente residenciasPaciente = (ResidenciasPaciente) object;
		try {
			em.getTransaction().begin();
			em.persist(residenciasPaciente);
			em.getTransaction().commit();
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return residenciasPaciente;
	}

	@Override
	public Object findById(Long id) {
		try {
			return em.find(ResidenciasPaciente.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object updateById(Object object) {
		ResidenciasPaciente residenciasPacienteUpdate = (ResidenciasPaciente) object;
		em.getTransaction().begin();
		em.merge(residenciasPacienteUpdate);
		em.getTransaction().commit();
		return residenciasPacienteUpdate;
	}

	@Override
	public void delete(Long id) {
		em.getTransaction().begin();
		var residenciasPaciente = (ResidenciasPaciente) findById(id);
		if (residenciasPaciente != null) {
			em.remove(residenciasPaciente);
		}
		em.getTransaction().commit();
	}

	public List<ResidenciasPaciente> findAll() {
		Query query = em.createQuery("SELECT rp FROM ResidenciasPaciente rp", ResidenciasPaciente.class);
		return query.getResultList();
	}
}
