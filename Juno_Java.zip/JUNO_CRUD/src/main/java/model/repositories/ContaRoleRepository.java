package model.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dao.BasicCrud;
import model.entities.ContaRole;

public class ContaRoleRepository implements BasicCrud {
	private EntityManager em;

	public ContaRoleRepository() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("junoVersaoFinal");
		this.em = emf.createEntityManager();
	}

	@Override
	public Object create(Object object) {
		ContaRole contaRole = (ContaRole) object;
		// se o email n estiver sendo usado
		em.getTransaction().begin();
		em.persist(contaRole);
		em.getTransaction().commit();
		return contaRole;
	}

	// consulta o banco e verifica se o email ja foi cadastrado
	public boolean isEmailInUse(String email) {
		// Consultar o banco de dados para verificar se o e-mail já está em uso
		Query query = em.createQuery("SELECT COUNT(cr) FROM ContaRole cr WHERE cr.email = :email", Long.class);
		query.setParameter("email", email);
		Long count = (Long) query.getSingleResult();
		return count > 0;
	}

	@Override
	public Object findById(Long id) {
		try {
			return em.find(ContaRole.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object updateById(Object object) {
		ContaRole contaRoleUpdate = (ContaRole) object;
		em.getTransaction().begin();
		em.merge(contaRoleUpdate);
		em.getTransaction().commit();
		return contaRoleUpdate;
	}

	@Override
	public void delete(Long id) {
		em.getTransaction().begin();
		var contaRole = (ContaRole) findById(id);
		if (contaRole != null) {
			em.remove(contaRole);
		}
		em.getTransaction().commit();
	}

	public List<ContaRole> findAll() {
		List<ContaRole> query = em.createQuery("SELECT cr FROM ContaRole cr", ContaRole.class).getResultList();
		return query;
	}
}
