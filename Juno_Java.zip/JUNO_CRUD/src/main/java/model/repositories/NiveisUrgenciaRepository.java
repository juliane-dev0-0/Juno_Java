package model.repositories;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dao.BasicCrud;
import model.entities.NiveisUrgencia;

// vai interagir com o banco 

public class NiveisUrgenciaRepository implements BasicCrud {
	private EntityManager em;

	public NiveisUrgenciaRepository() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("junoVersaoFinal");
		this.em = emf.createEntityManager();
	}

	@Override
	public Object create(Object object) {
		NiveisUrgencia niveisUrgencia = (NiveisUrgencia) object;
		try {
			em.getTransaction().begin();
			em.persist(niveisUrgencia);
			em.getTransaction().commit();
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return niveisUrgencia;
	}

	@Override
	public Object findById(Long id) {
		try {
			return em.find(NiveisUrgencia.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object updateById(Object object) {
		NiveisUrgencia niveisUrgenciaUpdate = (NiveisUrgencia) object;
		em.getTransaction().begin();
		em.merge(niveisUrgenciaUpdate);
		em.getTransaction().commit();
		return niveisUrgenciaUpdate;
	}

	@Override
	public void delete(Long id) {
		em.getTransaction().begin();
		var niveisUrgencia = (NiveisUrgencia) findById(id);
		if (niveisUrgencia != null) {
			em.remove(niveisUrgencia);
		}
		em.getTransaction().commit();
	}

	public List<NiveisUrgencia> findAll() {
		Query query = em.createQuery("SELECT nu FROM NiveisUrgencia nu", NiveisUrgencia.class);
		return query.getResultList();
	}
}
