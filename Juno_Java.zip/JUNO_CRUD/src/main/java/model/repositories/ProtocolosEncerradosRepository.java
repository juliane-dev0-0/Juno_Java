package model.repositories;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dao.BasicCrud;
import model.entities.ProtocolosEncerrados;

// vai interagir com o banco 

public class ProtocolosEncerradosRepository implements BasicCrud {
	private EntityManager em;

	public ProtocolosEncerradosRepository() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("junoVersaoFinal");
		this.em = emf.createEntityManager();
	}

	@Override
	public Object create(Object object) {
		ProtocolosEncerrados protocolosEncerrados = (ProtocolosEncerrados) object;
		try {
			em.getTransaction().begin();
			em.persist(protocolosEncerrados);
			em.getTransaction().commit();
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return protocolosEncerrados;
	}

	@Override
	public Object findById(Long id) {
		try {
			return em.find(ProtocolosEncerrados.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object updateById(Object object) {
		ProtocolosEncerrados protocolosEncerradosUpdate = (ProtocolosEncerrados) object;
		em.getTransaction().begin();
		em.merge(protocolosEncerradosUpdate);
		em.getTransaction().commit();
		return protocolosEncerradosUpdate;
	}

	@Override
	public void delete(Long id) {
		em.getTransaction().begin();
		var protocolosEncerrados = (ProtocolosEncerrados) findById(id);
		if (protocolosEncerrados != null) {
			em.remove(protocolosEncerrados);
		}
		em.getTransaction().commit();
	}

	public List<ProtocolosEncerrados> findAll() {
		Query query = em.createQuery("SELECT proto FROM ProtocolosEncerrados proto", ProtocolosEncerrados.class);
		return query.getResultList();
	}
}
