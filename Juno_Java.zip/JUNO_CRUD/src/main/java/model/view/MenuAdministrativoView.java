package model.view;

import java.util.List;
import java.util.Scanner;

import model.controller.ContaController;
import model.controller.ContaRoleController;
import model.controller.EquipeController;
//import model.controller.ProtocolosEncerradosController;
import model.controller.PublicoController;
import model.controller.UsuarioController;
import model.entities.Conta;
import model.entities.ContaRole;
import model.entities.Equipe;
import model.entities.Publico;
import model.entities.Usuario;

/*TL;DR:: LISTA DE SERVICES A SEREM CRIADOS/IMPLEMENTADOS DENTRO DA SEGUINTE VIEW(QUE SERÁ DECOMPOSTA EM DIFERENTES SERVICES)
     • ADMINISTRATIVO
	    - verificaLoginAdministrativo;
	       ‣ será necessário verificar se existe uma conta compatível com as credenciais fornecidas e se a conta encontrada possui acesso administrativo.
	 • CONTAS
	    - criarConta;
	       ‣ será necessário verificar se já existe uma conta com o CPF fornecido antes de permitir que a conta seja criada
	    - listarContas; 
	    - editarConta; 
	    - deletarConta;
	 • NOTIFICACOES
	    - listarNotificacao
	    - editarCriteriosNotificacao
	 • EQUIPES
	    - criarEquipe;
	    - listarEquipes;
	    - editarEquipes;
	    - deletarEquipes;
    • PUBLICOS
	    - criarPublico;
	    - listarPublicos;
	    - editarPublico;
	    - deletarPublico;
    
 									*/

public class MenuAdministrativoView {

	private static UsuarioController usuarioController = new UsuarioController();
	private static ContaController contaController = new ContaController();
	private static EquipeController equipeController = new EquipeController();
	private static PublicoController publicoController = new PublicoController();
	private static ContaRoleController contaRoleController = new ContaRoleController();

	private Scanner scanner;

	// Realiza a operação de Login dentro do Menu Administrativo
	public Conta loginAdministrativo() {
		Scanner leitorLoginAdm = new Scanner(System.in);
		String tentativaEmail = null, tentativaSenha = null;
		Conta contaLogin = null; // variável do tipo conta, onde será armazenada a Conta encontrada caso o login
									// seja bem-sucedido

		boolean loginAdministrativo = true;

		while (loginAdministrativo == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|         Juno - Login Administrativo                     |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖°   Digite o email vinculado à Conta Administrativa  ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");
			tentativaEmail = leitorLoginAdm.nextLine();

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖°   Digite a senha vinculada à Conta Administrativa  ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");
			tentativaSenha = leitorLoginAdm.nextLine();

			/*
			 * TODO: chamar a função para verificação da existência de uma conta que bate
			 * com as credenciais(login+senha)
			 */
			/*
			 * TODO: verificar se a conta encontrada possui acesso administrativo(não pode
			 * ser qualquer tipo de conta)
			 */

			/* TRECHO DO LOGIN */
			String verificaEmail;
			String verificaSenha;

			Usuario usuarioEncontrado;
			Usuario verificaGerente;

			Long verificaGerenteID;
			Long usuarioEncontradoID;

			ContaRole verificaRole;

			// Irá percorrer todos os usuários
			for (Usuario x : usuarioController.obterTodosUsuarios()) {
				/*
				 * System.out.println(x.getEmail()); System.out.println(x.getSenha());
				 */

				verificaEmail = x.getEmail(); // verifica em cada usuário se o email e a senha são os mesmos do registro
				verificaSenha = x.getSenha();

				if ((verificaEmail.equals(tentativaEmail)) && verificaSenha.equals(tentativaSenha)) {
					System.out.println("╔═════════════════════════════════╗");
					System.out.println("║ ⋆˚✿˖° Usuário Encontrado! ⋆˚✿˖° ║");
					System.out.println("╚═════════════════════════════════╝");
					usuarioEncontrado = x;// guarda o usuário que corresponde à busca na variável usuarioEncontrado
					// O for irá percorrer todas contas
					for (Conta y : contaController.obterTodosContas()) {
						verificaGerente = y.getGerente();
						verificaGerenteID = verificaGerente.getId();
						usuarioEncontradoID = usuarioEncontrado.getId();

						if (verificaGerenteID.equals(usuarioEncontradoID)) { // caso o Id do usuário encontrado e do
																				// usuário gerente da conta forem
																				// compatíveis, é deduzido que a conta
																				// pertence ao usuário encontrado
																				// previamente
							contaLogin = y;
							// System.out.println("ENCONTROU CONTA");
							verificaRole = contaLogin.getRole();
							if (verificaRole.getId().equals(1L)) {
								System.out.println(
										"╔════════════════════════════════════════════════════════════════════════════╗");
								System.out.println(
										"║ ⋆˚✿˖° Acesso liberado! A conta acessada possui acesso administrativo ⋆˚✿˖° ║");
								System.out.println(
										"╚════════════════════════════════════════════════════════════════════════════╝");
								break;
							} else {
								System.out.println(
										"╔═══════════════════════════════════════════════════════════════════════════════════════════════╗");
								System.out.println(
										"║ (｡•́︿•̀｡) Acesso negado! A conta acessada não possui liberação de acesso administrativo (｡•́︿•̀｡) ║");
								System.out.println(
										"╚═══════════════════════════════════════════════════════════════════════════════════════════════╝");

							}

						}
					}
				}

			}

			loginAdministrativo = false;

		}

		return contaLogin;

	}

	public void menuAdministrativo(Conta contaLogada) {
		Scanner leitorMenuAdm = new Scanner(System.in);
		int selecionaADM = 0;

		boolean menuAdministrativo = true;

		while (menuAdministrativo == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|              Juno - Menu Administrativo                 |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Central de Contas                                  |");
			System.out.println("|  2 - Central de Notificações                            |");
			System.out.println("|  3 - Central de Equipes                                 |");
			System.out.println("|  4 - Central de Públicos                                |");
			System.out.println("|  5 - Retornar ao Menu Principal (DESLOGAR)              |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			selecionaADM = leitorMenuAdm.nextInt();
			switch (selecionaADM) {
			case 1:
				menuConta();
				break;
			case 2:
				menuNotificacoes();
				break;
			case 3:
				menuEquipes();
				break;
			case 4:
				menuPublicos();
				break;
			case 5:
				menuAdministrativo = false;
				break;
			default:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║  (｡•́︿•̀｡)   Opção Inválida! Selecione novamente  (｡•́︿•̀｡)   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
				break;
			}
		}

	}

	public void menuConta() {
		Scanner leitorMenuConta = new Scanner(System.in);
		int selecionaConta = 0;

		boolean menuConta = true;

		while (menuConta == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|           Administrativo - Central de Contas            |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Criar Conta                                        |");
			System.out.println("|  2 - Listar Contas                                      |");
			System.out.println("|  3 - Editar Conta                                       |");
			System.out.println("|  4 - Deletar Conta                                      |");
			System.out.println("|  5 - Retornar à Central Administrativa                  |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			selecionaConta = leitorMenuConta.nextInt();

			switch (selecionaConta) {
			case 1:
				criarConta();
				break;
			case 2:
				listarConta();
				break;
			case 3:
				editarConta();
				break;
			case 4:
				deletarConta();
				break;
			case 5:
				menuConta = false;
				break;
			default:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║  (｡•́︿•̀｡)   Opção Inválida! Selecione novamente  (｡•́︿•̀｡)   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
				break;
			}

		}

	}

	public void menuNotificacoes() {
		Scanner leitorMenuNotif = new Scanner(System.in);
		int selecionaNotif = 0;

		boolean menuNotificacoes = true;

		while (menuNotificacoes == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|        Administrativo - Central de Notificações         |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Listar Notificação                                 |");
			System.out.println("|  2 - Editar Critérios de Notificação                    |");
			System.out.println("|  3 - Retornar à Central Administrativa                  |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			selecionaNotif = leitorMenuNotif.nextInt();

			switch (selecionaNotif) {
			case 1:

				break;
			case 2:

				break;
			case 3:
				menuNotificacoes = false;
				break;
			default:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║  (｡•́︿•̀｡)   Opção Inválida! Selecione novamente  (｡•́︿•̀｡)   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
				break;
			}
		}
	}

	public void menuEquipes() {
		Scanner leitorMenuEquipe = new Scanner(System.in);
		int selecionaEquipe = 0;

		boolean menuEquipes = true;

		while (menuEquipes == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|        Administrativo - Central de Equipes              |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Criar Equipe                                       |");
			System.out.println("|  2 - Listar Equipes                                     |");
			System.out.println("|  3 - Editar Equipes                                     |");
			System.out.println("|  4 - Deletar Equipes                                    |");
			System.out.println("|  5 - Retornar à Central Administrativa                  |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			selecionaEquipe = leitorMenuEquipe.nextInt();

			switch (selecionaEquipe) {
			case 1:
				criarEquipe();
				break;
			case 2:
				listarEquipe();
				break;
			case 3:
				editarEquipe();
				break;
			case 4:
				deletarEquipe();
				break;
			case 5:
				menuEquipes = false;
				break;
			default:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║  (｡•́︿•̀｡)   Opção Inválida! Selecione novamente  (｡•́︿•̀｡)   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
				break;
			}

		}
	}

	public void menuPublicos() {
		Scanner leitorMenuPublicos = new Scanner(System.in);

		boolean menuPublicos = true;

		int selecionaPublicos = 0;

		while (menuPublicos == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|        Administrativo - Central de Públicos             |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Criar Público                                      |");
			System.out.println("|  2 - Listar Públicos                                    |");
			System.out.println("|  3 - Editar Público                                     |");
			System.out.println("|  4 - Deletar Público                                    |");
			System.out.println("|  5 - Retornar à Central Administrativa                  |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			selecionaPublicos = leitorMenuPublicos.nextInt();

			switch (selecionaPublicos) {
			case 1:
				criarPublico();
				break;
			case 2:
				listarPublico();
				break;
			case 3:
				editarPublico();
				break;
			case 4:
				deletarPublico();
				break;
			case 5:
				menuPublicos = false;
				break;
			default:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║  (｡•́︿•̀｡)   Opção Inválida! Selecione novamente  (｡•́︿•̀｡)   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
				break;
			}
		}

	}

	// MÉTODOS REFERENTES A CONTAS

	public void criarConta() {

		Scanner criaContaScanner = new Scanner(System.in);
		try {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧");
			System.out.println("|  Criar nova Conta   |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧");

			// obtendo informações do usuário
			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o ID do Usuário que irá Gerenciar a Conta  ⋆˚✿˖°  ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");
			Long gerenteId = criaContaScanner.nextLong();

			System.out.println("╔═══════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o ID do Role que irá atribuir à Conta  ⋆˚✿˖° ║");
			System.out.println("╚═══════════════════════════════════════════════════════════╝");
			Long roleId = criaContaScanner.nextLong();

			System.out.println("╔═════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o ID do Público ao qual a Conta fará parte.  ⋆˚✿˖° ║");
			System.out.println("╚═════════════════════════════════════════════════════════════════╝");
			Long publicoId = criaContaScanner.nextLong();

			System.out.println("╔═════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o ID da Equipe a qual a Conta fará parte.    ⋆˚✿˖° ║");
			System.out.println("╚═════════════════════════════════════════════════════════════════╝");
			Long equipeId = criaContaScanner.nextLong();

			// criação dos objetos com base nos IDs
			Usuario gerente = new Usuario();
			gerente.setId(gerenteId);

			ContaRole role = new ContaRole();
			role.setId(roleId);

			Publico publico = new Publico();
			publico.setIdPublico(publicoId);

			Equipe equipe = new Equipe();
			equipe.setIdEquipe(equipeId);

			// criação da conta
			Conta conta = new Conta();
			conta.setGerente(gerente);
			conta.setRole(role);
			conta.setPublico(publico);
			conta.setEquipe(equipe);

			// chamando o controlador para adicionar a conta
			Conta novaConta = contaController.adicionarConta(conta);

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Conta criada com sucesso! ID da conta:" + novaConta.getIdConta() + "⋆˚✿˖°  ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

		} catch (Exception e) {
			System.out.println("(｡•́︿•̀｡)   Erro ao criar a conta" + e.getMessage() + "  (｡•́︿•̀｡)   ");
		}
	}

	public void listarConta() {
		List<Conta> contas = contaController.obterTodosContas();
		for (Conta conta : contas) {
			System.out.println("\nID: " + conta.getIdConta() + " USUARIO ID: " + conta.getGerente() + " ROLE: "
					+ conta.getRole() + " PUBLICO: " + conta.getPublico() + " EQUIPE: " + conta.getEquipe());
		}
	}

	public void editarConta() {
		Scanner editarContaScanner = new Scanner(System.in);

		Conta contaSelecionada;

		Usuario novoGerente;
		ContaRole novoRole;
		Publico novoPublico;
		Equipe novaEquipe;

		try {
			System.out.println("╔═════════════════════════════════════════════════════╗");
			System.out.println("║  ⋆˚✿˖°  Digite o ID da Conta a ser editada   ⋆˚✿˖°  ║");
			System.out.println("╚═════════════════════════════════════════════════════╝");

			Long idContaEditar = editarContaScanner.nextLong();
			editarContaScanner.nextLine();

			contaSelecionada = contaController.obterContaPorId(idContaEditar);

			if (contaSelecionada == null) {
				System.out.println("╔═══════════════════════════════════════════════════════════════════════╗");
				System.out.println("║  (｡•́︿•̀｡) O ID fornecido não está presente no Banco de Dados (｡•́︿•̀｡)   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════════════════╝");
			} else {
				System.out.println("Gerente atual da Conta: " + contaSelecionada.getGerente().getId());
				System.out.println("Informe o ID do novo Gerente da Conta:");
				Long idNovoGerente = editarContaScanner.nextLong();
				editarContaScanner.nextLine();

				novoGerente = usuarioController.obterUsuarioPorId(idNovoGerente);

				if (novoGerente != null) {
					contaSelecionada.setGerente(novoGerente);
				}

				System.out.println("Role atual da Conta: " + contaSelecionada.getRole().getId());
				System.out.println("Informe o novo Role da Conta:");
				Long idNovoRole = editarContaScanner.nextLong();
				editarContaScanner.nextLine();

				novoRole = contaRoleController.obterContaRolePorId(idNovoRole);

				if (novoRole != null) {
					contaSelecionada.setRole(novoRole);
				}

				System.out.println("Público atual da Conta: " + contaSelecionada.getPublico().getIdPublico());
				System.out.println("Informe o novo Público da Conta:");
				Long idNovoPublico = editarContaScanner.nextLong();
				editarContaScanner.nextLine();

				novoPublico = publicoController.obterPublicoPorId(idNovoPublico);

				if (novoPublico != null) {
					contaSelecionada.setPublico(novoPublico);
				}

				System.out.println("Equipe atual da Conta: " + contaSelecionada.getEquipe().getIdEquipe());
				System.out.println("Informe a nova Equipe da Conta:");
				Long idNovaEquipe = editarContaScanner.nextLong();
				editarContaScanner.nextLine();

				novaEquipe = equipeController.obterEquipePorId(idNovaEquipe);

				if (novaEquipe != null) {
					contaSelecionada.setEquipe(novaEquipe);
				}

				Conta contaAtualizada = contaController.atualizarConta(contaSelecionada);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/*
	 * Scanner editarContaScanner = new Scanner(System.in); Conta contaSelecionada;
	 * 
	 * Long novoIdConta; ContaRole novoRoleConta; Publico novoPublicoConta; Equipe
	 * novaEquipeConta;
	 * 
	 * try {
	 * System.out.println("╔═════════════════════════════════════════════════════╗")
	 * ;
	 * System.out.println("║  ⋆˚✿˖° Informe o ID da Conta a ser editada   ⋆˚✿˖°  ║"
	 * );
	 * System.out.println("╚═════════════════════════════════════════════════════╝")
	 * ;
	 * 
	 * Long idContaSelecionada = editarContaScanner.nextLong();
	 * editarContaScanner.nextLine();
	 * 
	 * contaSelecionada = contaController.obterContaPorId(idContaSelecionada);
	 * 
	 * if(contaSelecionada == null) { System.out.println(
	 * "╔═══════════════════════════════════════════════════════════════════════╗");
	 * System.out.
	 * println("║  (｡•́︿•̀｡) O ID fornecido não está presente no Banco de Dados (｡•́︿•̀｡)   ║"
	 * ); System.out.println(
	 * "╚═══════════════════════════════════════════════════════════════════════╝");
	 * }
	 * 
	 * System.out.println("Role atual da Conta: "+contaSelecionada.getRole().getId()
	 * ); System.out.println("Informe o novo Role da Conta: "); novoRole =
	 * 
	 * 
	 * }catch (Exception e) { System.out.println("Erro ao editar Público: " +
	 * e.getMessage()); }
	 */

	public void deletarConta() {
		Scanner deletarContaScanner = new Scanner(System.in);
		System.out.println("\nID da conta a ser excluida: ");
		Long idContaExcluida = deletarContaScanner.nextLong();
		deletarContaScanner.nextLine();

		Conta contaParaExcluir = contaController.obterContaPorId(idContaExcluida);

		if (contaParaExcluir != null) {
			contaController.deletarConta(idContaExcluida);
			System.out.println("\nConta excluída com sucesso!");
		} else {
			System.out.println("\nConta não encontrada!");
		}
	}

	// MÉTODOS REFERENTES A NOTIFICAÇÕES

	// MÉTODOS REFERENTES A EQUIPES
	public void criarEquipe() {
		Scanner criarEquipeScanner = new Scanner(System.in);
		try {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧");
			System.out.println("|  Criar nova Equipe   |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧");

			// obtendo informações da Equipe
			System.out.println("Nome da Equipe:");
			String nomeEquipe = criarEquipeScanner.nextLine();

			System.out.println("Descrição da Equipe:");
			String descEquipe = criarEquipeScanner.nextLine();

			// criação da Equipe

			Equipe equipe = new Equipe();
			equipe.setNome(nomeEquipe);
			equipe.setDescricao(descEquipe);

			// chamando o controller para adicionar a equipe
			Equipe novaEquipe = equipeController.adicionarEquipe(equipe);
			System.out.println("Equipe criada com sucesso! ID da Equipe:" + novaEquipe.getIdEquipe());
		} catch (Exception e) {
			System.out.println("Erro ao criar Equipe: " + e.getMessage());
		}
	}

	public void listarEquipe() {
		List<Equipe> equipes = equipeController.obterTodosEquipes();
		for (Equipe equipe : equipes) {
			System.out.println("\nID: " + equipe.getIdEquipe() + " NOME DA EQUIPE: " + equipe.getNome() + " DESCRIÇÃO"
					+ equipe.getDescricao());
		}
	}

	public void editarEquipe() {
		Scanner editarEquipeScanner = new Scanner(System.in);

		Equipe equipeSelecionada;

		String novoNome, novaDesc;

		try {
			System.out.println("╔═════════════════════════════════════════════════════╗");
			System.out.println("║  ⋆˚✿˖° Informe o ID da Equipe a ser editada  ⋆˚✿˖°  ║");
			System.out.println("╚═════════════════════════════════════════════════════╝");

			Long idEquipeEditar = editarEquipeScanner.nextLong();
			editarEquipeScanner.nextLine();

			equipeSelecionada = equipeController.obterEquipePorId(idEquipeEditar);

			if (equipeSelecionada == null) {
				System.out.println("╔═══════════════════════════════════════════════════════════════════════╗");
				System.out.println("║  (｡•́︿•̀｡) O ID fornecido não está presente no Banco de Dados (｡•́︿•̀｡)   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════════════════╝");
			}

			else {
				System.out.println("Nome atual da Equipe:" + equipeSelecionada.getNome());
				System.out.println("Informe o novo nome da Equipe:");
				novoNome = editarEquipeScanner.nextLine();

				if (novoNome.isEmpty() == false) {
					equipeSelecionada.setNome(novoNome);
				}

				System.out.println("Descrição atual da Equipe: " + equipeSelecionada.getDescricao());
				System.out.println("Informe a nova descrição do Público:");
				novaDesc = editarEquipeScanner.nextLine();

				if (novaDesc.isEmpty() == false) {
					equipeSelecionada.setDescricao(novaDesc);
				}

				Equipe equipeAtualizada = equipeController.atualizarEquipe(equipeSelecionada);
			}
			/*
			 * else {
			 * System.out.println("Nome atual do Público: "+publicoSelecionado.getNome());
			 * System.out.println("Informe o novo nome do Público:"); novoNome =
			 * editarPublicoScanner.nextLine();
			 * 
			 * if (novoNome.isEmpty() == false) { publicoSelecionado.setNome(novoNome); }
			 * 
			 * System.out.println("Descrição atual da Equipe: "+publicoSelecionado.
			 * getDescricao()); System.out.println("Informe a nova descrição do Público:");
			 * novaDesc = editarPublicoScanner.nextLine();
			 * 
			 * if (novaDesc.isEmpty() == false) { publicoSelecionado.setDescricao(novaDesc);
			 * }
			 * 
			 * Publico publicoAtualizado =
			 * publicoController.atualizarPublico(publicoSelecionado); System.out.println();
			 * }
			 */

		} catch (Exception e) {
			System.out.println("Erro ao editar Público: " + e.getMessage());
		}
	}

	public void deletarEquipe() {
		Scanner deletarEquipeScanner = new Scanner(System.in);
		System.out.println("ID da Equipe a ser excluída:");

		Long idEquipeExcluida = deletarEquipeScanner.nextLong();
		deletarEquipeScanner.nextLine();

		Equipe equipeParaExcluir = equipeController.obterEquipePorId(idEquipeExcluida);

		if (equipeParaExcluir != null) {
			equipeController.deletarEquipe(idEquipeExcluida);
			System.out.println("Equipe excluída com sucesso!");
		} else {
			System.out.println("Equipe não encontrada!");
		}

	}

	// MÉTODOS REFERENTES A PUBLICOS
	public void criarPublico() {
		Scanner criarPublicoScanner = new Scanner(System.in);
		try {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧");
			System.out.println("|  Criar novo Público  |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧");

			// obtendo informações do Público
			System.out.println("Nome do Público:");
			String nomePublico = criarPublicoScanner.nextLine();

			System.out.println("Descrição do Público:");
			String descricaoPublico = criarPublicoScanner.nextLine();

			// criação do Público
			Publico publico = new Publico();
			publico.setNome(nomePublico);
			publico.setDescricao(descricaoPublico);

			// chamando o controller para adicionar o Público
			Publico novoPublico = publicoController.adicionarPublico(publico);
			System.out.println("Público criado com sucesso! ID do Público" + novoPublico.getIdPublico());

		} catch (Exception e) {
			System.out.println("Erro ao criar Público: " + e.getMessage());
		}

	}

	public void listarPublico() {
		List<Publico> publicos = publicoController.obterTodosPublicos();
		for (Publico publico : publicos) {
			System.out.println("\nID:" + publico.getIdPublico() + " NOME DO PÚBLICO:" + publico.getNome()
					+ " DESCRIÇÃO:" + publico.getDescricao());
		}

	}

	public void editarPublico() {
		Scanner editarPublicoScanner = new Scanner(System.in);
		Publico publicoSelecionado;

		String novoNome, novaDesc;
		try {
			System.out.println("╔══════════════════════════════════════════════════════╗");
			System.out.println("║  ⋆˚✿˖° Informe o ID do Público a ser editado  ⋆˚✿˖°  ║");
			System.out.println("╚══════════════════════════════════════════════════════╝");

			Long idPublicoEditar = editarPublicoScanner.nextLong();
			editarPublicoScanner.nextLine();

			publicoSelecionado = publicoController.obterPublicoPorId(idPublicoEditar); // Determina o Público que será
																						// editado com base no ID
																						// fornecido

			if (publicoSelecionado == null) {
				System.out.println("O id fornecido não está presente no Banco de Dados");
			}

			else {
				System.out.println("Nome atual do Público: " + publicoSelecionado.getNome());
				System.out.println("Informe o novo nome do Público:");
				novoNome = editarPublicoScanner.nextLine();

				if (novoNome.isEmpty() == false) {
					publicoSelecionado.setNome(novoNome);
				}

				System.out.println("Descrição atual da Equipe: " + publicoSelecionado.getDescricao());
				System.out.println("Informe a nova descrição do Público:");
				novaDesc = editarPublicoScanner.nextLine();

				if (novaDesc.isEmpty() == false) {
					publicoSelecionado.setDescricao(novaDesc);
				}

				Publico publicoAtualizado = publicoController.atualizarPublico(publicoSelecionado);
				System.out.println();
			}
		} catch (Exception e) {
			System.out.println("Erro ao editar Público: " + e.getMessage());
		}

	}

	public void deletarPublico() {
		Scanner deletarPublicoScanner = new Scanner(System.in);
		System.out.println("ID do Público a ser excluído:");

		Long idPublicoExcluido = deletarPublicoScanner.nextLong();
		deletarPublicoScanner.nextLine();

		Publico publicoParaExcluir = publicoController.obterPublicoPorId(idPublicoExcluido);

		if (publicoParaExcluir != null) {
			publicoController.deletarPublico(idPublicoExcluido);
			System.out.println("Público excluído com sucesso!");
		} else {
			System.out.println("Público não encontrado!");
		}
	}

}

/*
 * FROM-NOTION: 1. Menu Administrativo
 * 
 * — login (TODOS OS ABAIXO ESTÃO SERÃO APENAS ACESSÍVEIS APÓS O LOGIN)
 * 
 * 1. MENU DE CONTAS - criar contas - listar contas - editar contas - deletar
 * contas 2. MENU DE NOTIFICAÇÕES - listar notificação (ele só vai printar,
 * seria usado para consulta depois de editar os critérios) - editar critérios
 * de notificação 3. MENU DE EQUIPES - criar equipes - listar equipes - editar
 * equipes - deletar equipes 4. MENU DE PUBLICOS - criar publicos - listar
 * publicos - editar publicos - deletar publicos
 */