package model.view;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import model.controller.EquipeController;
import model.controller.PacienteController;
import model.controller.UsuarioController;
import model.entities.Equipe;
import model.entities.Paciente;
import model.entities.Usuario;

public class CadastroEquipeTela extends javax.swing.JFrame {

	private List<String> pacientesSelecionados = new ArrayList<>();
	private List<String> usuariosSelecionados = new ArrayList<>();
	private EquipeController equipeController = new EquipeController();

	public CadastroEquipeTela() {
		initComponents();
		new ComboBoxMembros().carregarComboBoxEquipes(jComboBox1);
		new ComboBoxPacientes().carregarComboBoxPacientes(jComboBox1_1);
	}

	@SuppressWarnings("unchecked")
	private void initComponents() {
		jLabel2 = new javax.swing.JLabel();
		jComboBox1 = new javax.swing.JComboBox<>();
		jLabel3 = new javax.swing.JLabel();
		jScrollPane1 = new javax.swing.JScrollPane();
		jScrollPane2 = new javax.swing.JScrollPane();
		tabelaNomes = new javax.swing.JTable();

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("Criar Equipe");

		jLabel2.setText("MEMBROS:");

		jComboBox1.setModel(new DefaultComboBoxModel<>(new String[] { "Selecione o usuário" }));
		jComboBox1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String usuario = (String) jComboBox1.getSelectedItem();
				if (usuario != null && !usuario.equals("Selecione o usuário")
						&& !usuariosSelecionados.contains(usuario)) {
					usuariosSelecionados.add(usuario);
					atualizarTabela();
				}
			}
		});

		jLabel3.setText("DESCRIÇÃO:");

		tabelaNomes.setModel(new DefaultTableModel(new Object[][] { { null, null }, { null, null }, },
				new String[] { "Pacientes", "Membros" }));
		jScrollPane2.setViewportView(tabelaNomes);
		jTextArea1 = new javax.swing.JTextArea();

		jTextArea1.setColumns(20);
		jTextArea1.setRows(5);

		lblPacientes = new JLabel();
		lblPacientes.setText("PACIENTES:");

		jComboBox1_1 = new JComboBox<>();
		jComboBox1_1.setModel(
				new DefaultComboBoxModel(new String[] { "Selecione o paciente", "1", "2", "3", "4", "5", "6", "7" }));
		jComboBox1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String paciente = (String) jComboBox1_1.getSelectedItem();
				if (paciente != null && !paciente.equals("Selecione o paciente")
						&& !pacientesSelecionados.contains(paciente)) {
					pacientesSelecionados.add(paciente);
					atualizarTabela();
				}
			}
		});

		JButton adicionarEquipe = new JButton("Criar Equipe");
		adicionarEquipe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// quando clicar aí adiciona no banco nova equipe

				criarEquipe();
			}
		});

		JButton CancelarE = new JButton("Cancelar");

		JLabel lblNewLabel = new JLabel("TÍTULO ");

		nomeTitulo = new JTextField();
		nomeTitulo.setColumns(10);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		layout.setHorizontalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup()
				.addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup()
						.addGap(22)
						.addGroup(layout.createParallelGroup(Alignment.TRAILING)
								.addGroup(layout.createSequentialGroup().addComponent(jLabel2).addGap(18).addComponent(
										jComboBox1, GroupLayout.PREFERRED_SIZE, 205, GroupLayout.PREFERRED_SIZE))
								.addGroup(layout.createSequentialGroup()
										.addGroup(layout.createParallelGroup(Alignment.LEADING)
												.addComponent(lblPacientes, GroupLayout.PREFERRED_SIZE, 66,
														GroupLayout.PREFERRED_SIZE)
												.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 45,
														GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(ComponentPlacement.RELATED)
										.addGroup(layout.createParallelGroup(Alignment.LEADING, false)
												.addComponent(nomeTitulo)
												.addComponent(jComboBox1_1, 0, 205, Short.MAX_VALUE))))
						.addPreferredGap(ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
						.addGroup(layout.createParallelGroup(Alignment.LEADING)
								.addComponent(jLabel3, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE)
								.addComponent(jTextArea1, GroupLayout.PREFERRED_SIZE, 286, GroupLayout.PREFERRED_SIZE))
						.addGap(44))
						.addGroup(layout.createSequentialGroup().addGap(100)
								.addComponent(jScrollPane2, GroupLayout.PREFERRED_SIZE, 422, GroupLayout.PREFERRED_SIZE)
								.addGap(18)
								.addGroup(layout.createParallelGroup(Alignment.LEADING)
										.addComponent(CancelarE, GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
										.addComponent(adicionarEquipe, GroupLayout.DEFAULT_SIZE, 121,
												Short.MAX_VALUE))))
				.addGap(213).addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
						GroupLayout.PREFERRED_SIZE)
				.addGap(76)));
		layout.setVerticalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup()
				.addGap(34)
				.addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel).addComponent(
						nomeTitulo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addGap(40)
				.addGroup(layout.createParallelGroup(Alignment.LEADING)
						.addGroup(layout.createSequentialGroup().addComponent(jLabel3)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(jTextArea1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE)
								.addGap(86).addComponent(adicionarEquipe).addGap(19).addComponent(CancelarE))
						.addGroup(layout.createSequentialGroup()
								.addGroup(layout.createParallelGroup(Alignment.BASELINE)
										.addComponent(lblPacientes, GroupLayout.PREFERRED_SIZE, 13,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(
												jComboBox1_1, GroupLayout.PREFERRED_SIZE, 19,
												GroupLayout.PREFERRED_SIZE))
								.addGroup(layout.createParallelGroup(Alignment.LEADING)
										.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE,
												GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
										.addGroup(layout.createSequentialGroup().addGap(42)
												.addGroup(layout.createParallelGroup(Alignment.BASELINE)
														.addComponent(jLabel2).addComponent(jComboBox1,
																GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
												.addGap(87).addComponent(jScrollPane2, GroupLayout.PREFERRED_SIZE, 130,
														GroupLayout.PREFERRED_SIZE)))))
				.addGap(10)));
		getContentPane().setLayout(layout);

		setSize(new Dimension(706, 433));
		setLocationRelativeTo(null);
	}

	private void criarEquipe() {
		// Coleta os dados do campo da descrição para poder adicionar no banco
		String descricao = jTextArea1.getText();
		String nomeEquipe = nomeTitulo.getText();

		if (nomeEquipe.trim().isEmpty()) {
			JOptionPane.showMessageDialog(this, "O título da equipe não pode estar vazio.", "Erro",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		if (pacientesSelecionados.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Selecione pelo menos um paciente.", "Erro", JOptionPane.ERROR_MESSAGE);
			return;
		}

		if (usuariosSelecionados.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Selecione pelo menos um membro.", "Erro", JOptionPane.ERROR_MESSAGE);
			return;
		}

		Equipe equipe = new Equipe();
		equipe.setNome(nomeEquipe);
		equipe.setDescricao(descricao);
		equipe.setNomePaciente(String.join(",", pacientesSelecionados));
		equipe.setNomeUsuario(String.join(",", usuariosSelecionados)); // Concatena os nomes

		PacienteController pacienteController = new PacienteController();
		for (String nomePaciente : pacientesSelecionados) {
			Paciente paciente = pacienteController.obterPacientePorNome(nomePaciente);
			if (paciente == null) {
				JOptionPane.showMessageDialog(this, "O paciente " + nomePaciente + " não existe no banco de dados.",
						"Erro", JOptionPane.ERROR_MESSAGE);
				return;
			}
		}

		// Adiciona a equipe
		Equipe novaEquipe = equipeController.adicionarEquipe(equipe);

		// Exibe uma mensagem de confirmação
		if (novaEquipe != null) {
			JOptionPane.showMessageDialog(this, "Equipe criada com sucesso!", "Sucesso",
					JOptionPane.INFORMATION_MESSAGE);
		} else {
			JOptionPane.showMessageDialog(this, "Erro ao criar equipe.", "Erro", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void atualizarTabela() {
		DefaultTableModel model = (DefaultTableModel) tabelaNomes.getModel();
		model.setRowCount(0);

		for (String paciente : pacientesSelecionados) {
			model.addRow(new Object[] { paciente, "" });
		}

		for (String usuario : usuariosSelecionados) {
			boolean added = false;
			for (int i = 0; i < model.getRowCount(); i++) {
				if (model.getValueAt(i, 1).equals("")) {
					model.setValueAt(usuario, i, 1);
					added = true;
					break;
				}
			}
			if (!added) {
				model.addRow(new Object[] { "", usuario });
			}
		}
//iria colocar descrição mas vi q é meio inútil, dps converso sobre isso.
//		for (String descricoes : descricao) {
//			model.addRow(new Object[] { descricoes, "" });
//		}
	}

	public static void main(String args[]) {
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(CadastroEquipeTela.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(CadastroEquipeTela.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(CadastroEquipeTela.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(CadastroEquipeTela.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		}

		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new CadastroEquipeTela().setVisible(true);
			}
		});
	}

	private javax.swing.JComboBox<String> jComboBox1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JTable tabelaNomes;
	private javax.swing.JTextArea jTextArea1;
	private JLabel lblPacientes;
	private JComboBox<String> jComboBox1_1;
	private JTextField nomeTitulo;

	private class ComboBoxMembros {

		private void carregarComboBoxEquipes(javax.swing.JComboBox<String> comboBox) {
			new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						UsuarioController usuarioC = new UsuarioController();
						List<Usuario> usuarios = usuarioC.obterTodosUsuarios();
						SwingUtilities.invokeLater(() -> {
							comboBox.removeAllItems();
							comboBox.addItem("Selecione o usuário");
							for (Usuario users : usuarios) {
								String nomeUsuario = users.getNome();
								comboBox.addItem(nomeUsuario);
							}
						});
					} catch (Exception ex) {
						SwingUtilities.invokeLater(() -> {
							JOptionPane.showMessageDialog(null, "Ocorreu um erro inesperado:\n" + ex.getMessage(),
									"ERRO!", JOptionPane.ERROR_MESSAGE);
						});
					}
				}
			}).start();
		}
	}

	private class ComboBoxPacientes {

		private void carregarComboBoxPacientes(javax.swing.JComboBox<String> comboBox) {
			new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						PacienteController pacienteC = new PacienteController();
						List<Paciente> pacientes = pacienteC.obterTodosPacientes();
						SwingUtilities.invokeLater(() -> {
							comboBox.removeAllItems();
							comboBox.addItem("Selecione o paciente");
							for (Paciente p : pacientes) {
								String nomePaciente = p.getNome();
								comboBox.addItem(nomePaciente);
							}
						});
					} catch (Exception ex) {
						SwingUtilities.invokeLater(() -> {
							JOptionPane.showMessageDialog(null, "Ocorreu um erro inesperado:\n" + ex.getMessage(),
									"ERRO!", JOptionPane.ERROR_MESSAGE);
						});
					}
				}
			}).start();
		}
	}
}
