package model.view;

import java.util.Scanner;
import java.util.Date;
import model.controller.ProtocoloPreNatalController;
import model.entities.Paciente;
import model.entities.ProtocoloPreNatal;

public class ProtocoloView {

	private ProtocoloPreNatalController protocoloController;
	private Scanner scanner;

	public ProtocoloView() {
		this.protocoloController = new ProtocoloPreNatalController();
		this.scanner = new Scanner(System.in);
	}

	public void adicionarProtocoloPreNatal(Paciente paciente) {
		try {
			System.out.println("Adicionando um novo protocolo pré-natal");

			Scanner scanner = new Scanner(System.in);

			System.out.print("Data de abertura (AAAA-MM-DD): ");
			String dataAberturaStr = scanner.nextLine();
			Date dataAbertura = java.sql.Date.valueOf(dataAberturaStr);

			System.out.print("Abertura aprovada (true/false): ");
			boolean aberturaAprovada = scanner.nextBoolean();
			scanner.nextLine(); // Consumindo a quebra de linha

			// Data de encerramento é opcional
			Date dataEncerramento = null;
			System.out.print("Data de encerramento (AAAA-MM-DD, pressione Enter se não aplicável): ");
			String dataEncerramentoStr = scanner.nextLine();
			if (!dataEncerramentoStr.isEmpty()) {
				dataEncerramento = java.sql.Date.valueOf(dataEncerramentoStr);
			}

			System.out.print("Status do protocolo: ");
			int statusProtocolo = scanner.nextInt();
			scanner.nextLine(); // Consumindo a quebra de linha

			System.out.print("DUM (AAAA-MM-DD): ");
			String dumStr = scanner.nextLine();
			Date dum = java.sql.Date.valueOf(dumStr);

			System.out.print("DPP (AAAA-MM-DD): ");
			String dppStr = scanner.nextLine();
			Date dpp = java.sql.Date.valueOf(dppStr);

			System.out.print("Número de testes rápidos: ");
			int numTestesRapidos = scanner.nextInt();
			scanner.nextLine(); // Consumindo a quebra de linha

			System.out.print("Número de consultas odontológicas: ");
			int numConsultasOdontologicas = scanner.nextInt();
			scanner.nextLine(); // Consumindo a quebra de linha

			// criando o objeto protocolo pré-natal
			ProtocoloPreNatal protocolo = new ProtocoloPreNatal();
			protocolo.setDataAbertura(dataAbertura);
			protocolo.setAberturaAprovada(aberturaAprovada);
			protocolo.setDataEncerramento(dataEncerramento);
			protocolo.setStatusProtocolo(statusProtocolo);
			protocolo.setDum(dum);
			protocolo.setDpp(dpp);
			protocolo.setNumTestesRapidos(numTestesRapidos);
			protocolo.setNumConsultasOdontologicas(numConsultasOdontologicas);

			// fefinindo o paciente associado ao protocolo
			protocolo.setPaciente(paciente);

			// chamando o controlador para adicionar o protocolo pré-natal
			ProtocoloPreNatal novoProtocolo = protocoloController.adicionarProtocoloPreNatal(protocolo);
			System.out.println(
					"Protocolo pré-natal adicionado com sucesso! ID do protocolo: " + novoProtocolo.getIdProtocolo());

		} catch (Exception e) {
			System.out.println("Erro ao adicionar o protocolo pré-natal: " + e.getMessage());
		}
	}

	public static void main(String[] args) {

		ProtocoloView view = new ProtocoloView();

		// to usando um paciente ja existente nesse caso, trocar no menu
		Paciente paciente = new Paciente();
		paciente.setIdPaciente(1L); // supondo que o paciente com ID 1 já existe no sistema

		view.adicionarProtocoloPreNatal(paciente);
	}
}
