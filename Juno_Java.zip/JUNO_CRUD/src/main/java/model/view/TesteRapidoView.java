package model.view;

import java.util.Scanner;
import java.util.Date;
import model.controller.TesteRapidoController;
import model.entities.Paciente;
import model.entities.ProtocoloPreNatal;
import model.entities.TesteRapido;

public class TesteRapidoView {

	private TesteRapidoController testeRapidoController;
	private Scanner scanner;

	public TesteRapidoView() {
		this.testeRapidoController = new TesteRapidoController();
		this.scanner = new Scanner(System.in);
	}

	public void adicionarTesteRapido(Paciente paciente, ProtocoloPreNatal protocolo) {
		try {
			System.out.println("Adicionando um novo teste rápido");

			System.out.print("Data do teste (AAAA-MM-DD): ");
			String dataTesteStr = scanner.nextLine();
			Date dataTeste = java.sql.Date.valueOf(dataTesteStr);

			System.out.print("Exame de sangue (0 para negativo, 1 para positivo): ");
			int exameSangue = Integer.parseInt(scanner.nextLine());

			System.out.print("Exame de urina (0 para negativo, 1 para positivo): ");
			int exameUrina = Integer.parseInt(scanner.nextLine());

			System.out.print("Descrição: ");
			String descricao = scanner.nextLine();

			// Criando o objeto teste rápido
			TesteRapido testeRapido = new TesteRapido();
			testeRapido.setDataTeste(dataTeste);
			testeRapido.setExameSangue(exameSangue);
			testeRapido.setExameUrina(exameUrina);
			testeRapido.setDescricao(descricao);

			// Definindo o paciente e protocolo associados ao teste
			testeRapido.setPacienteConsultado(paciente);
			testeRapido.setProtocoloPertencente(protocolo);

			// Chamando o controlador para adicionar o teste rápido
			TesteRapido novoTesteRapido = testeRapidoController.adicionarTesteRapido(testeRapido);
			System.out
					.println("Teste rápido adicionado com sucesso! ID do teste: " + novoTesteRapido.getIdTesteRapido());

		} catch (Exception e) {
			System.out.println("Erro ao adicionar o teste rápido: " + e.getMessage());
		}
	}

	public static void main(String[] args) {
		TesteRapidoView view = new TesteRapidoView();

		// Supondo que já temos um paciente e um protocolo criados
		Paciente paciente = new Paciente();
		paciente.setIdPaciente(1L); // Supostamente o paciente com ID 1 já existe no sistema

		ProtocoloPreNatal protocolo = new ProtocoloPreNatal();
		protocolo.setIdProtocolo(1L); // Supostamente o protocolo com ID 1 já existe no sistema

		// Adicionando um novo teste rápido associado ao paciente e protocolo
		view.adicionarTesteRapido(paciente, protocolo);
	}
}
