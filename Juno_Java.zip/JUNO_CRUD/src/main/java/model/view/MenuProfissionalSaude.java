package model.view;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import model.controller.ConsultaOdontologicaController;
import model.controller.ContaController;
import model.controller.PacienteController;
import model.controller.ProtocoloPreNatalController;
import model.controller.TesteRapidoController;
import model.controller.UsuarioController;
import model.entities.ConsultaOdontologica;
import model.entities.Conta;
import model.entities.ContaRole;
import model.entities.Equipe;
import model.entities.Paciente;
import model.entities.ProtocoloPreNatal;
import model.entities.TesteRapido;
import model.entities.Usuario;

public class MenuProfissionalSaude {

	private static PacienteController pacienteController = new PacienteController();
	private static ProtocoloPreNatalController protocoloController = new ProtocoloPreNatalController();
	private static UsuarioController usuarioController = new UsuarioController();
	private static ContaController contaController = new ContaController();
	private static TesteRapidoController testeRapidoController = new TesteRapidoController();
	private static ConsultaOdontologicaController consultaOdontologicaController = new ConsultaOdontologicaController();

	private Scanner scanner = new Scanner(System.in);

	public Conta loginProfissionalSaude() {
		Scanner leitorLoginSaude = new Scanner(System.in);
		String tentativaEmail = null, tentativaSenha = null;
		Conta contaLogin = null; // variável do tipo conta, onde será armazenada a Conta encontrada caso o login
									// seja bem-sucedido

		boolean loginSaude = true;

		while (loginSaude == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|         Juno - Login do Profissional da Saúde           |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖°   Digite o email vinculado à Conta Administrativa  ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			tentativaEmail = leitorLoginSaude.nextLine();

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖°   Digite a senha vinculada à Conta Administrativa  ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");
			tentativaSenha = leitorLoginSaude.nextLine();

			/*
			 * todo 1: chamar a função para verificação da existência de uma conta que bate
			 * com as credenciais(login+senha) todo 2: verificar se a conta encontrada
			 * possui acesso todo 3: adicionar mensagens de CONTA NÃO ENCONTRADA e ACESSO
			 * NEGADO, dependendo do caso
			 */
			/* TRECHO DO LOGIN */
			String verificaEmail;
			String verificaSenha;

			Usuario usuarioEncontrado;
			Usuario verificaGerente;

			Long verificaGerenteID;
			Long usuarioEncontradoID;

			ContaRole verificaRole;

			for (Usuario x : usuarioController.obterTodosUsuarios()) {
				/*
				 * System.out.println(x.getEmail()); System.out.println(x.getSenha());
				 */

				verificaEmail = x.getEmail(); // verifica em cada usuário se o email e a senha são os mesmos do registro
				verificaSenha = x.getSenha();

				if ((verificaEmail.equals(tentativaEmail)) && verificaSenha.equals(tentativaSenha)) {
					System.out.println("╔═════════════════════════════════╗");
					System.out.println("║ ⋆˚✿˖° Usuário Encontrado! ⋆˚✿˖° ║");
					System.out.println("╚═════════════════════════════════╝");
					usuarioEncontrado = x;// guarda o usuário que corresponde à busca na variável usuarioEncontrado
					// O for irá percorrer todas contas
					for (Conta y : contaController.obterTodosContas()) {
						verificaGerente = y.getGerente();
						verificaGerenteID = verificaGerente.getId();
						usuarioEncontradoID = usuarioEncontrado.getId();

						if (verificaGerenteID.equals(usuarioEncontradoID)) { // caso o Id do usuário encontrado e do
																				// usuário gerente da conta forem
																				// compatíveis, é deduzido que a conta
																				// pertence ao usuário encontrado
																				// previamente
							contaLogin = y;
							verificaRole = contaLogin.getRole();
							if (verificaRole.getId().equals(2L)) {
								System.out.println(
										"╔══════════════════════════════════════════════════════════════════════════════════════╗");
								System.out.println(
										"║ ⋆˚✿˖° Acesso liberado! A conta acessada possui acesso do Profissional de Saúde ⋆˚✿˖° ║");
								System.out.println(
										"╚══════════════════════════════════════════════════════════════════════════════════════╝");
								break;
							} else {
								System.out.println(
										"╔═════════════════════════════════════════════════════════════════════════════════════════════════════════╗");
								System.out.println(
										"║ (｡•́︿•̀｡) Acesso negado! A conta acessada não possui liberação de acesso do Profissional de Saúde (｡•́︿•̀｡) ║");
								System.out.println(
										"╚═════════════════════════════════════════════════════════════════════════════════════════════════════════╝");

							}

						}
					}
				}

			}
			loginSaude = false; // todo: remover, está aqui apenas para encerrar o loop enquanto a verificação
								// ainda não foi implementada

		}
		return contaLogin;

	}

	public void menuProfissionalSaude(Conta contaLogada) {

		Scanner leitorMenuPS = new Scanner(System.in); // PS = profisional da saúde
		int selecionaPS = 0;

		boolean menuPS = true;

		while (menuPS == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|           Juno - Menu do Profissional da Saúde          |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Central de Atendimento                             |");
			System.out.println("|  2 - Cadastrar Novo Paciente                            |");
			System.out.println("|  3 - Listar Notificações                                |");
			System.out.println("|  4 - Consultar Dados do Profissional                    |");// todo: potencialmente
																								// podemos inserir o
																								// nome do Profissional
																								// em algum lugar do
																								// print? para ficar
																								// mais específico a
																								// cada usuário
			System.out.println("|  5 - Retornar ao Menu Principal (DESLOGAR)              |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			selecionaPS = leitorMenuPS.nextInt();
			switch (selecionaPS) {
			case 1:
				menuAtendimento();
				break;
			case 2:
				cadastrarPaciente();
				break;
			case 3:
				break;
			case 4:
				listarDadosProfissional(contaLogada);
				break;
			case 5:
				menuPS = false;
				break;
			default:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║  ⋆˚✿˖°    Opção Inválida! Selecione novamente     ⋆˚✿˖°   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
				break;
			}
		}

	}

	public void menuAtendimento() {
		Scanner leitorMenuAtnd = new Scanner(System.in);
		int selecionaAtnd = 0;
		boolean menuAtnd = true;
		Long idEntradaPaciente;
		Paciente pacienteSelecionado = null;

		System.out.println("╔═══════════════════════════════════════════════╗");
		System.out.println("║ ⋆˚✿˖° Digite o ID associado ao Paciente ⋆˚✿˖° ║");
		System.out.println("╚═══════════════════════════════════════════════╝");
		idEntradaPaciente = leitorMenuAtnd.nextLong();
		leitorMenuAtnd.nextLine();

		for (Paciente x : pacienteController.obterTodosPacientes()) {
			if (idEntradaPaciente.equals(x.getIdPaciente())) {
				pacienteSelecionado = x;
				System.out.println("╔══════════════════════════════════╗");
				System.out.println("║ ⋆˚✿˖° Paciente Encontrado! ⋆˚✿˖° ║");
				System.out.println("╚══════════════════════════════════╝");

			}
		}

		if (pacienteSelecionado == null) {
			System.out.println("╔══════════════════════════════════════════════════════════════════════════════╗");
			System.out.println("║  (｡•́︿•̀｡) O Paciente selecionado não está presente no Banco de Dados (｡•́︿•̀｡)  ║");
			System.out.println("╚══════════════════════════════════════════════════════════════════════════════╝");
			return;
		}

		while (menuAtnd == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|        Profissional da Saúde - Menu de Atendimento      |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Central de Exames                                  |");
			System.out.println("|  2 - Central do Pré-Natal                               |");
			System.out.println("|  3 - Central do Paciente                                |");
			System.out.println("|  4 - Retornar ao Menu do Profissional da Saúde          |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			selecionaAtnd = leitorMenuAtnd.nextInt();

			switch (selecionaAtnd) {
			case 1:
				menuExames(pacienteSelecionado);
				break;
			case 2:
				menuPreNatal(pacienteSelecionado);
				break;
			case 3:
				menuPaciente(pacienteSelecionado);
				break;
			case 4:
				menuAtnd = false;
				break;
			default:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║  ⋆˚✿˖°    Opção Inválida! Selecione novamente     ⋆˚✿˖°   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
				break;

			}

		}

	}

	public void menuExames(Paciente paciente) {
		Scanner leitorMenuExames = new Scanner(System.in);
		int selecionaExames = 0;

		boolean menuExames = true;

		while (menuExames == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|       Menu de Atendimento - Central de Exames           |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Registrar Novo Exame                               |");
			System.out.println("|  2 - Listar Exames do Paciente                          |");
			System.out.println("|  3 - Editar Exame                                       |");
			System.out.println("|  4 - Deletar Exame                                      |");
			System.out.println("|  5 - Retornar ao Menu de Atendimento                    |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			selecionaExames = leitorMenuExames.nextInt();

			switch (selecionaExames) {
			case 1:
				criarExame(paciente);
				break;
			case 2:
				listarExames(paciente);
				break;
			case 3:
				// TODO
				break;
			case 4:
				// TODO
				break;
			case 5:
				menuExames = false;
				break;
			default:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║  ⋆˚✿˖°    Opção Inválida! Selecione novamente     ⋆˚✿˖°   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
				break;
			}

		}
	}

	public void menuPreNatal(Paciente paciente) {
		Scanner leitorMenuPN = new Scanner(System.in);
		int selecionaPN = 0;

		boolean menuPN = true;

		while (menuPN == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|       Menu de Atendimento - Central do Pré-Natal        |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Registrar Novo Protocolo Pré-Natal                 |");
			System.out.println("|  2 - Atualizar Protocolo Atual                          |");
			System.out.println("|  3 - Listar Protocolos                                  |");
			System.out.println("|  4 - Editar Protocolo Encerrado                         |");
			System.out.println("|  5 - Deletar Protocolo                                  |");
			System.out.println("|  6 - Retornar ao Menu de Atendimento                    |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			selecionaPN = leitorMenuPN.nextInt();

			switch (selecionaPN) {
			case 1:
				registrarPreNatal(paciente); // TODO
				// Verificar o parametro
				break;
			case 2:
				// TODO
				break;
			case 3:
				// TODO
				break;
			case 4:
				// TODO
				break;
			case 5:
				// TODO
				break;
			case 6:
				menuPN = false;
				break;
			default:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║  ⋆˚✿˖°    Opção Inválida! Selecione novamente     ⋆˚✿˖°   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
				break;
			}

		}
	}

	public void menuPaciente(Paciente paciente) {
		Scanner leitorP = new Scanner(System.in);
		int selecionaMP = 0;

		boolean menuP = true;

		while (menuP == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|       Menu de Atendimento - Central do Paciente         |"); // todo: adicionar o nome
																								// do paciente no print?
																								// pt2
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Central de Endereços                               |");
			System.out.println("|  2 - Central de Dados Cadastrais                        |");
			System.out.println("|  3 - Retornar ao Menu de Atendimento                    |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			selecionaMP = leitorP.nextInt();

			switch (selecionaMP) {
			case 1:
				menuEnderecos(paciente);
				break;
			case 2:
				menuDadosPaciente(paciente);
				break;
			case 3:
				menuP = false;
				break;
			default:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║  ⋆˚✿˖°    Opção Inválida! Selecione novamente     ⋆˚✿˖°   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
				break;
			}
		}
	}

	public void menuEnderecos(Paciente paciente) {
		Scanner leitorMenuEnd = new Scanner(System.in);
		int selecionaMenuEnd = 0;

		boolean menuEnd = true;

		while (menuEnd == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|       Menu do Paciente - Central de Endereços           |"); // todo: adicionar o nome
																								// do paciente no print?
																								// pt2
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Adicionar Endereço                                 |");
			System.out.println("|  2 - Listar Residências                                 |");
			System.out.println("|  3 - Editar Residência                                  |");
			System.out.println("|  4 - Deletar Endereço                                   |");
			System.out.println("|  5 - Retornar ao Menu do Paciente                       |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			selecionaMenuEnd = leitorMenuEnd.nextInt();

			switch (selecionaMenuEnd) {
			case 1:
				// TODO
				break;
			case 2:
				// TODO
				break;
			case 3:
				// TODO
				break;
			case 4:
				// TODO
				break;
			case 5:
				menuEnd = false;
				break;
			default:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║  ⋆˚✿˖°    Opção Inválida! Selecione novamente     ⋆˚✿˖°   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
				break;
			}
		}
	}

	public void menuDadosPaciente(Paciente paciente) {
		Scanner leitorDadosP = new Scanner(System.in);
		int selecionaDadosP = 0;

		boolean menuDP = true;

		while (menuDP == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|     Menu do Paciente - Central de Dados Cadastrais      |"); // todo: adicionar o nome
																								// do paciente no print?
																								// pt2
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Listar Dados                                       |");
			System.out.println("|  2 - Editar Dados                                       |");
			System.out.println("|  3 - Deletar Dados                                      |");
			System.out.println("|  4 - Retornar ao Menu do Paciente                       |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			selecionaDadosP = leitorDadosP.nextInt();

			switch (selecionaDadosP) {
			case 1:
				listarDadosPaciente(paciente);
				break;
			case 2:
				editarDadosPaciente(paciente);
				break;
			case 3:
				deletarDadosPaciente(paciente);
				break;
			case 4:
				menuDP = false;
				break;
			default:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║  ⋆˚✿˖°    Opção Inválida! Selecione novamente     ⋆˚✿˖°   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
				break;
			}
		}
	}

	// PACIENTE

	public void cadastrarPaciente() {
		try {
			System.out.println("Adicionando um novo paciente");

			// obtem as informaçoes do paciente
			System.out.print("Nome do paciente: ");
			String nome = scanner.nextLine();

//			System.out.print("Data de nascimento (AAAA-MM-DD): ");
//			String dataNascimentoStr = scanner.nextLine();
//			Date dataNascimento = java.sql.Date.valueOf(dataNascimentoStr);

			System.out.print("Tipo sanguíneo: ");
			String tipoSanguineo = scanner.nextLine();

			System.out.print("Status pré-natal: ");
			int statusPreNatal = scanner.nextInt();
			scanner.nextLine();
			System.out.print("Telefone: ");
			String telefone = scanner.nextLine();

			// criando o objeto paciente
			Paciente paciente = new Paciente();
			paciente.setNome(nome);
			// paciente.setDataNascimento(dataNascimento);
			paciente.setTipoSanguineo(tipoSanguineo);
//			paciente.setStatusPreNatal(statusPreNatal);
			paciente.setTelefone(telefone);

			// passando o id da equipe responsável
			System.out.print("ID da equipe responsável: ");
			Long idEquipe = scanner.nextLong();
			Equipe equipe = new Equipe();
			equipe.setIdEquipe(idEquipe);
			paciente.setEquipeResponsavel(equipe);

			// chamando o controlador para adicionar o paciente
			Paciente novoPaciente = pacienteController.adicionarPaciente(paciente);
			System.out.println("Paciente adicionado com sucesso! ID do paciente: " + novoPaciente.getIdPaciente());

		} catch (Exception e) {
			System.out.println("Erro ao adicionar o paciente: " + e.getMessage());
		}
	}

	// CONSULTA DE DADOS DO PROFISSIONAL
	public void listarDadosProfissional(Conta contaProfissional) {
		Usuario gerente = contaProfissional.getGerente();

		System.out.println("Dados da Conta:");
		System.out.println("Id da Conta: " + contaProfissional.getIdConta());
		System.out.println("Role atribuído à Conta: " + contaProfissional.getRole());
		System.out.println("Público atribuído à Conta: " + contaProfissional.getPublico());
		System.out.println("Dados Pessoais:");
		System.out.println("Nome:" + gerente.getNome());
		System.out.println("CPF:" + gerente.getCpf());
		System.out.println("Email:" + gerente.getEmail());
	}

	// PRE NATAL

	public void registrarPreNatal(Paciente paciente) {
		try {
			System.out.println("Adicionando um novo protocolo pré-natal");

			Scanner scanner = new Scanner(System.in);

			System.out.print("Data de abertura (AAAA-MM-DD): ");
			String dataAberturaStr = scanner.nextLine();
			Date dataAbertura = java.sql.Date.valueOf(dataAberturaStr);

			System.out.print("Abertura aprovada (true/false): ");
			boolean aberturaAprovada = scanner.nextBoolean();
			scanner.nextLine();

			// data de encerramento é opcional
			Date dataEncerramento = null;
			System.out.print("Data de encerramento (AAAA-MM-DD, pressione Enter se não aplicável): ");
			String dataEncerramentoStr = scanner.nextLine();
			if (!dataEncerramentoStr.isEmpty()) {
				dataEncerramento = java.sql.Date.valueOf(dataEncerramentoStr);
			}

			System.out.print("Status do protocolo: ");
			int statusProtocolo = scanner.nextInt();
			scanner.nextLine();

			System.out.print("DUM (AAAA-MM-DD): ");
			String dumStr = scanner.nextLine();
			Date dum = java.sql.Date.valueOf(dumStr);

			System.out.print("DPP (AAAA-MM-DD): ");
			String dppStr = scanner.nextLine();
			Date dpp = java.sql.Date.valueOf(dppStr);

			System.out.print("Número de testes rápidos: ");
			int numTestesRapidos = scanner.nextInt();
			scanner.nextLine();

			System.out.print("Número de consultas odontológicas: ");
			int numConsultasOdontologicas = scanner.nextInt();
			scanner.nextLine();

			// criando o objeto protocolo pré-natal
			ProtocoloPreNatal protocolo = new ProtocoloPreNatal();
			protocolo.setDataAbertura(dataAbertura);
			protocolo.setAberturaAprovada(aberturaAprovada);
			protocolo.setDataEncerramento(dataEncerramento);
			protocolo.setStatusProtocolo(statusProtocolo);
			protocolo.setDum(dum);
			protocolo.setDpp(dpp);
			protocolo.setNumTestesRapidos(numTestesRapidos);
			protocolo.setNumConsultasOdontologicas(numConsultasOdontologicas);

			// definindo o paciente associado ao protocolo
			protocolo.setPaciente(paciente);

			// chamando o controlador para adicionar o protocolo pré-natal
			ProtocoloPreNatal novoProtocolo = protocoloController.adicionarProtocoloPreNatal(protocolo);
			System.out.println(
					"Protocolo pré-natal adicionado com sucesso! ID do protocolo: " + novoProtocolo.getIdProtocolo());
			// TODO nao completo, adicionar o paciente

		} catch (Exception e) {
			System.out.println("Erro ao adicionar o protocolo pré-natal: " + e.getMessage());
		}
	}

// EXAMES
	public void criarExame(Paciente paciente) {
		boolean menuCriaExame = true;
		Scanner leitorCriaExame = new Scanner(System.in);
		int selecionaMenuExame = 0;

		while (menuCriaExame == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|   Central de Atendimento - Selecionar Tipo de Exame     |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Teste Rápido                                       |");
			System.out.println("|  2 - Consulta Odontológica                              |");
			System.out.println("|  3 - Retornar à Central de Exames (Cancela Operação)    |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");
			selecionaMenuExame = leitorCriaExame.nextInt();
			leitorCriaExame.nextLine();

			switch (selecionaMenuExame) {
			case 1:
				System.out.print("ID do protocolo pré-natal: ");
				Long idProtocoloTeste = leitorCriaExame.nextLong();
				leitorCriaExame.nextLine();
				ProtocoloPreNatal protocoloTeste = protocoloController.obterProtocoloPreNatalPorId(idProtocoloTeste);
				adicionarTesteRapido(paciente, protocoloTeste); // chama o método e passa os parametros
				break;
			case 2:
				System.out.print("ID do protocolo pré-natal: ");
				Long idProtocoloConsulta = leitorCriaExame.nextLong();
				leitorCriaExame.nextLine();
				ProtocoloPreNatal protocoloConsulta = protocoloController
						.obterProtocoloPreNatalPorId(idProtocoloConsulta);
				adicionarConsultaOdontologica(paciente, protocoloConsulta);
				break;
			case 3:
				menuCriaExame = false;
				break;
			default:
				break;
			}
		}
	}

	public void adicionarTesteRapido(Paciente paciente, ProtocoloPreNatal protocolo) {
		try {
			System.out.println("Adicionando um novo teste rápido");

			Scanner scanner = new Scanner(System.in);
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

			System.out.print("Data do teste (AAAA-MM-DD): ");
			String dataTesteStr = scanner.nextLine();
			Date dataTeste = dateFormat.parse(dataTesteStr);

			System.out.print("Exame de sangue (0 para negativo, 1 para positivo): ");
			int exameSangue = Integer.parseInt(scanner.nextLine());

			System.out.print("Exame de urina (0 para negativo, 1 para positivo): ");
			int exameUrina = Integer.parseInt(scanner.nextLine());

			System.out.print("Descrição: ");
			String descricao = scanner.nextLine();

			TesteRapido testeRapido = new TesteRapido();
			testeRapido.setDataTeste(dataTeste);
			testeRapido.setExameSangue(exameSangue);
			testeRapido.setExameUrina(exameUrina);
			testeRapido.setDescricao(descricao);

			testeRapido.setPacienteConsultado(paciente);
			testeRapido.setProtocoloPertencente(protocolo);

			TesteRapido novoTesteRapido = testeRapidoController.adicionarTesteRapido(testeRapido);
			System.out
					.println("Teste rápido adicionado com sucesso! ID do teste: " + novoTesteRapido.getIdTesteRapido());

		} catch (ParseException e) {
			System.out.println("Data do teste inválida. Use o formato AAAA-MM-DD.");
		} catch (Exception e) {
			System.out.println("Erro ao adicionar o teste rápido: " + e.getMessage());
		}
	}

	public void adicionarConsultaOdontologica(Paciente paciente, ProtocoloPreNatal protocolo) {
		try {
			System.out.println("Adicionando uma nova consulta odontológica");

			Scanner scanner = new Scanner(System.in);
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

			System.out.print("Data da consulta (AAAA-MM-DD): ");
			String dataConsultaStr = scanner.nextLine();
			Date dataConsulta = dateFormat.parse(dataConsultaStr);

			System.out.print("Descrição: ");
			String descricao = scanner.nextLine();

			ConsultaOdontologica consultaOdontologica = new ConsultaOdontologica();
			consultaOdontologica.setDataAtendimento(dataConsulta);
			consultaOdontologica.setDescricao(descricao);

			consultaOdontologica.setPacienteConsultado(paciente);
			consultaOdontologica.setProtocoloPertencente(protocolo);

			ConsultaOdontologica novaConsultaOdontologica = consultaOdontologicaController
					.adicionarConsultaOdontologica(consultaOdontologica);
			System.out.println("Consulta odontológica adicionada com sucesso! ID da consulta: "
					+ novaConsultaOdontologica.getIdConsultaOdontologica());

		} catch (ParseException e) {
			System.out.println("Data da consulta inválida. Use o formato AAAA-MM-DD.");
		} catch (Exception e) {
			System.out.println("Erro ao adicionar a consulta odontológica: " + e.getMessage());
		}
	}

	public void listarExames(Paciente paciente) {
		System.out.println("Será?");
		// List<TesteRapido> testesRapidos =
		// testeRapidoController.obterTodosTesteRapidos();
		/*
		 * for(TesteRapido x : testesRapidos ) {
		 * System.out.println("\nID: "+x.getIdTesteRapido()+" DATA TESTE: "+x.
		 * getDataTeste()); }
		 */

		/*
		 * List<Equipe> equipes = equipeController.obterTodosEquipes(); for(Equipe
		 * equipe : equipes) {
		 * System.out.println("\nID: "+equipe.getIdEquipe()+" NOME DA EQUIPE: "+equipe.
		 * getNome()+"DESCRIÇÃO"+equipe.getDescricao()); }
		 */

	}

	// Listar dados do paciente

	public void listarDadosPaciente(Paciente paciente) {
		System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
		System.out.println("|                Dados do Paciente                        |");
		System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
		System.out.println("Nome: " + paciente.getNome());
		System.out.println("Data de Nascimento: " + paciente.getDataNascimento());
		System.out.println("Tipo Sanguíneo: " + paciente.getTipoSanguineo());
		System.out.println("Status Pré-Natal: " + paciente.getStatusPreNatal());
		System.out.println("Telefone: " + paciente.getTelefone());
		System.out.println("ID da Equipe Responsável: " + paciente.getEquipeResponsavel().getIdEquipe());
		System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •\n");
	}

// editar dados paciente

	public void editarDadosPaciente(Paciente paciente) {
		Scanner leitorDadosP = new Scanner(System.in);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
		System.out.println("|                Editar Dados do Paciente                 |");
		System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
		System.out.print("Nome: ");
		paciente.setNome(leitorDadosP.nextLine());
		System.out.print("Data de Nascimento (AAAA-MM-DD): ");
		String dataNascimentoStr = leitorDadosP.nextLine();
		try {
			Date dataNascimento = dateFormat.parse(dataNascimentoStr);
			paciente.setDataNascimento(dataNascimento);
		} catch (ParseException e) {
			System.out.println("Data de nascimento inválida. Use o formato AAAA-MM-DD.");
			return;
		}
		System.out.print("Tipo Sanguíneo: ");
		paciente.setTipoSanguineo(leitorDadosP.nextLine());
		System.out.print("Status Pré-Natal: ");
		// paciente.setStatusPreNatal(leitorDadosP.nextInt());
		leitorDadosP.nextLine(); // Consome a nova linha
		System.out.print("Telefone: ");
		paciente.setTelefone(leitorDadosP.nextLine());
		System.out.print("ID da Equipe Responsável: ");
		Long idEquipe = leitorDadosP.nextLong();
		Equipe equipe = new Equipe();
		equipe.setIdEquipe(idEquipe);
		paciente.setEquipeResponsavel(equipe);

		// att dados do paciente
		pacienteController.atualizarPaciente(paciente);
		System.out.println("Dados do paciente atualizados com sucesso!");
	}

	// deletar dados paciente

	public void deletarDadosPaciente(Paciente paciente) {
		Scanner leitorDadosP = new Scanner(System.in);
		System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
		System.out.println("|                Deletar Dados do Paciente                |");
		System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
		System.out.print("Tem certeza que deseja deletar os dados do paciente? (s/n): ");
		String confirmacao = leitorDadosP.nextLine();
		if (confirmacao.equalsIgnoreCase("s")) {
			// deletando dados do paciente pelo id atraves do controllador
			pacienteController.deletarPaciente(paciente.getIdPaciente());
			System.out.println("Dados do paciente deletados com sucesso!");
		} else {
			System.out.println("Operação cancelada.");
		}
	}

}
/*
 * FROM-NOTION::2. Menu de profissional da Saúde — login (TODOS OS ABAIXO ESTÃO
 * SERÃO APENAS ACESSÍVEIS APÓS O LOGIN) 1. MENU DE ATENDIMENTO (SELECIONARÁ O
 * PACIENTE NESSE MENU) - CENTRAL DE EXAMES - registrar novo exame (terá um
 * submenu para selecionar o tipo do exame: testeRapido, consultaOdontologica…)
 * - listar exames do paciente - deletar exames do sistema - editar exame -
 * CENTRAL DE PRÉ NATAL - abrir novo protocolo pré natal (terá um if,
 * verificando se já existe um protocolo prévio, prevenindo 2 protocolos abertos
 * simultaneamente) - atualizar protocolo atual - listar protocolos (listará
 * gestações atuais e passadas, caso existentes) - editar protocolo encerrado -
 * deletar protocolo - CENTRAL DO PACIENTE - MENU DE ENDEREÇOS - adicionar
 * endereço - listar residências - editar residências - deletar endereço
 * (impedir que o usuário delete o último endereço, deve existir no MÍNIMO um
 * endereço ligado a um paciente) - MENU DE DADOS CADASTRAIS - listar dados
 * (nome, dataNascimento, tipoSanguineo, telefone) - editar dados(dentro deste,
 * um submenu para selecionar qual dado do paciente deve ser alterado) - deletar
 * dados( idem, submenu) 2. CADASTRO DE NOVO PACIENTE 3. MENU DE NOTIFICAÇÕES -
 * listar notificações 4. CONSULTA DE CONTA - listar dados da conta (poderá ver
 * seus próprios dados como o nome da equipe a que pertence, qual role, etc;)
 */