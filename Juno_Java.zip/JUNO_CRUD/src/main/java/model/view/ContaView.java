package model.view;

import java.util.Scanner;
import model.controller.ContaController;
import model.entities.Conta;
import model.entities.ContaRole;
import model.entities.Equipe;
import model.entities.Publico;
import model.entities.Usuario;

public class ContaView {

	private ContaController contaController;
	private Scanner scanner;

	public ContaView() {
		this.contaController = new ContaController();
		this.scanner = new Scanner(System.in);
	}

	public void criarConta() {
		try {
			System.out.println("Criando uma nova conta");

			// Obtendo informações do usuário
			System.out.print("ID do Gerente: ");
			Long gerenteId = scanner.nextLong();

			System.out.print("ID do Role: ");
			Long roleId = scanner.nextLong();

			System.out.print("ID do Publico: ");
			Long publicoId = scanner.nextLong();

			System.out.print("ID da Equipe: ");
			Long equipeId = scanner.nextLong();

			// Criação dos objetos com base nos IDs
			Usuario gerente = new Usuario();
			gerente.setId(gerenteId);

			ContaRole role = new ContaRole();
			role.setId(roleId);

			Publico publico = new Publico();
			publico.setIdPublico(publicoId);

			Equipe equipe = new Equipe();
			equipe.setIdEquipe(equipeId);

			// Criação da conta
			Conta conta = new Conta();
			conta.setGerente(gerente);
			conta.setRole(role);
			conta.setPublico(publico);
			conta.setEquipe(equipe);

			// Chamando o controlador para adicionar a conta
			Conta novaConta = contaController.adicionarConta(conta);
			System.out.println("Conta criada com sucesso! ID da conta: " + novaConta.getIdConta());

		} catch (Exception e) {
			System.out.println("Erro ao criar a conta: " + e.getMessage());
		}
	}

	public static void main(String[] args) {
		ContaView view = new ContaView();
		view.criarConta();
	}
}
