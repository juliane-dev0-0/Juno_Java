package model.view;

import java.util.List;

import model.controller.ProtocolosEncerradosController;
import model.entities.ProtocolosEncerrados;

public class ProtocolosEncerradosView {

	private static ProtocolosEncerradosController protocolosController = new ProtocolosEncerradosController();

	public static void main(String[] args) {
		List<ProtocolosEncerrados> protocolos = protocolosController.obterTodosProtocolosEncerradoss();
		for (ProtocolosEncerrados protocolo : protocolos) {
			System.out.println("ID: " + protocolo.getIdProtocoloEncerrado() + " ID Original: "
					+ protocolo.getIdOriginalProtocolo() + " Abertura: " + protocolo.getDataAbertura()
					+ " ID GESTANTE: " + protocolo.getGestante() + " Encerramento: " + protocolo.getDataEncerramento());
		}

	}

}
