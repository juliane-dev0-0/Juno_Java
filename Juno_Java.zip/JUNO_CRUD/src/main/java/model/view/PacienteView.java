package model.view;

import java.util.Date;
import java.util.Scanner;

import model.controller.PacienteController;
import model.entities.Equipe;
import model.entities.Paciente;

public class PacienteView {

//	public tabelaPacientes pacientesTable;
	public PacienteController pacienteController;
	public Scanner scanner;

//	public PacienteView() {
//		this.pacienteController = new PacienteController();
//		this.scanner = new Scanner(System.in);
//		
//		
//	}

	public PacienteView() {
		this.pacienteController = new PacienteController();
//	    this.pacientesTable = (tabelaPacientes)pacientesTableComponent.getComponent(); 
		this.scanner = new Scanner(System.in);
	}

	public void adicionarPaciente() {
		try {
			System.out.println("Adicionando um novo paciente");

			// Obtendo informações do paciente
			System.out.print("Nome do paciente: ");
			String nome = scanner.nextLine();

			System.out.print("Data de nascimento (AAAA-MM-DD): ");
			String dataNascimentoStr = scanner.nextLine();
			Date dataNascimento = java.sql.Date.valueOf(dataNascimentoStr);

			System.out.print("Tipo sanguíneo: ");
			String tipoSanguineo = scanner.nextLine();

			System.out.print("Status pré-natal: ");
			int statusPreNatal = scanner.nextInt();
			scanner.nextLine(); // Consumindo a quebra de linha

			System.out.print("Telefone: ");
			String telefone = scanner.nextLine();

			// Criando o objeto paciente
			Paciente paciente = new Paciente();
			paciente.setNome(nome);
			paciente.setDataNascimento(dataNascimento);
			paciente.setTipoSanguineo(tipoSanguineo);
			// paciente.setStatusPreNatal(statusPreNatal);
			paciente.setTelefone(telefone);

			// Você pode precisar de mais interação com o usuário para definir a equipe
			// responsável
			// Por simplicidade, vamos apenas pedir o ID da equipe e criar uma instância de
			// Equipe para associar ao paciente
			System.out.print("ID da equipe responsável: ");
			Long idEquipe = scanner.nextLong();
			Equipe equipe = new Equipe();
			equipe.setIdEquipe(idEquipe);
			paciente.setEquipeResponsavel(equipe);

			// Chamando o controlador para adicionar o paciente
			Paciente novoPaciente = pacienteController.adicionarPaciente(paciente);
			System.out.println("Paciente adicionado com sucesso! ID do paciente: " + novoPaciente.getIdPaciente());

		} catch (Exception e) {
			System.out.println("Erro ao adicionar o paciente: " + e.getMessage());
		}
	}

	public static void main(String[] args) {
		PacienteView view = new PacienteView();
		view.adicionarPaciente();
	}
}
