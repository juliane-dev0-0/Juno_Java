/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package model.view;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.LayoutStyle.ComponentPlacement;

import model.entities.Usuario;
import model.repositories.UsuarioRepository;

public class TelaLogin extends javax.swing.JFrame {

	public TelaLogin() {
		initComponents();
	}

	@SuppressWarnings("unchecked")
	// <editor-fold defaultstate="collapsed" desc="Generated
	// Code">//GEN-BEGIN:initComponents
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jTextField1 = new javax.swing.JTextField();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();
		senhaL = new JPasswordField();
		JFormattedTextField emailL = new JFormattedTextField();

		jButton1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				String email = emailL.getText();
				String senha = senhaL.getText();

				UsuarioRepository ur = new UsuarioRepository();
				Usuario usuario = ur.findByEmailAndSenha(email, senha);

				if (usuario != null) {
					System.out.println("Login realizado com sucesso para o usuário: " + usuario.getNome());

					emailL.setText("");
					senhaL.setText("");

					new TelaPrincipalTela().setVisible(true);
					dispose();
				} else {
					System.out.println("Falha no login. Email ou senha incorretos.");

					JOptionPane.showMessageDialog(null, "Email ou senha incorretos", "Erro de Login",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setTitle("Tela de Login");

		jPanel1.setBackground(new java.awt.Color(255, 204, 204));

		jLabel1.setBackground(new java.awt.Color(255, 153, 153));
		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/logo.png"))); // NOI18N

		jTextField1.setBackground(new java.awt.Color(255, 204, 204));
		jTextField1.setFont(new java.awt.Font("Nirmala UI Semilight", 1, 24)); // NOI18N
		jTextField1.setForeground(new java.awt.Color(0, 0, 0));
		jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
		jTextField1.setText("Juno");
		jTextField1.setBorder(null);

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup().addGap(73, 73, 73).addComponent(jLabel1,
								javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGroup(jPanel1Layout.createSequentialGroup().addGap(133, 133, 133).addComponent(jTextField1,
								javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addContainerGap(84, Short.MAX_VALUE)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addGap(94, 94, 94)
						.addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 243,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(60, Short.MAX_VALUE)));

		jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/user (1).png"))); // NOI18N

		jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/block (2).png"))); // NOI18N
		jLabel3.setText("jLabel3");

		jLabel4.setText("USUÁRIO");

		jLabel5.setText("SENHA");

		jButton1.setBackground(new java.awt.Color(255, 204, 204));
		jButton1.setFont(new java.awt.Font("Ebrima", 0, 12)); // NOI18N
		jButton1.setForeground(new java.awt.Color(0, 0, 0));
		jButton1.setText("ENTRAR");

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		layout.setHorizontalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup()
				.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
				.addGroup(layout.createParallelGroup(Alignment.TRAILING).addGroup(layout.createSequentialGroup()
						.addGap(111)
						.addGroup(layout.createParallelGroup(Alignment.TRAILING).addComponent(jLabel2)
								.addComponent(jLabel3, GroupLayout.PREFERRED_SIZE, 24, GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(ComponentPlacement.RELATED)
						.addGroup(layout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(jLabel4, GroupLayout.PREFERRED_SIZE, 59, GroupLayout.PREFERRED_SIZE)
								.addComponent(jLabel5, GroupLayout.PREFERRED_SIZE, 49, GroupLayout.PREFERRED_SIZE)
								.addComponent(senhaL, GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
								.addComponent(emailL))
						.addContainerGap(176, Short.MAX_VALUE))
						.addGroup(layout.createSequentialGroup()
								.addPreferredGap(ComponentPlacement.RELATED, 205, Short.MAX_VALUE)
								.addComponent(jButton1).addGap(157)))));
		layout.setVerticalGroup(layout.createParallelGroup(Alignment.LEADING)
				.addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				.addGroup(layout.createSequentialGroup().addGap(116)
						.addGroup(layout.createParallelGroup(Alignment.LEADING)
								.addComponent(jLabel2, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
								.addGroup(layout.createSequentialGroup().addComponent(jLabel4)
										.addPreferredGap(ComponentPlacement.UNRELATED).addComponent(emailL,
												GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE)))
						.addGroup(layout.createParallelGroup(Alignment.LEADING, false)
								.addGroup(layout.createSequentialGroup().addGap(50).addComponent(jLabel3))
								.addGroup(layout.createSequentialGroup().addGap(42).addComponent(jLabel5)
										.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addComponent(senhaL, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE)))
						.addGap(62).addComponent(jButton1).addContainerGap(103, Short.MAX_VALUE)));
		getContentPane().setLayout(layout);

		setSize(new java.awt.Dimension(812, 448));
		setLocationRelativeTo(null);
	}

	public static void main(String args[]) {

		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}

		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new TelaLogin().setVisible(true);
//				frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
//				frame.setVisible(true);

				// new TelaLogin().setVisible(true);
			}
		});
	}

	// Variables declaration - do not modify//GEN-BEGIN:variables
	private javax.swing.JButton jButton1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JTextField jTextField1;
	private JPasswordField senhaL;
}
