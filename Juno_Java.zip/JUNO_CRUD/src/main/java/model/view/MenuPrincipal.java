package model.view;

import java.util.Scanner;

import model.entities.Conta;

public class MenuPrincipal {

	public static void main(String[] args) {

		/*
		 * todo: futuramente, mudar as declarações abaixo para refletir o local dos
		 * menus que serão chamados
		 */

		MenuAdministrativoView menuAdministrativoView = new MenuAdministrativoView();
		MenuProfissionalSaude menuProfissionalSaude = new MenuProfissionalSaude();
		////

		boolean menuPrincipal = true, 
				acessoAdmin = true, 
				acessoSaude = true;
		Scanner leitorMP = new Scanner(System.in);
		int selecionaMP = 0;

		Conta contaLogin;

		while (menuPrincipal == true) {
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|         Juno - Menu Principal                           |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");
			System.out.println("|  1 - Central de Acesso Administrativo                   |");
			System.out.println("|  2 - Central de Acesso do Profissional da Saúde         |");
			System.out.println("|  3 - Encerrar Programa                                  |");
			System.out.println("• ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ • ୨୧ • ┈ • ┈ •");

			System.out.println("╔════════════════════════════════════════════════════════════════╗");
			System.out.println("║ ⋆˚✿˖° Digite o número correspondente à operação desejada ⋆˚✿˖° ║");
			System.out.println("╚════════════════════════════════════════════════════════════════╝");

			selecionaMP = leitorMP.nextInt();
			switch (selecionaMP) {
			case 1:
				// Primeiro, faremos o login (este, retornará a conta que está logada)
				while (acessoAdmin == true) {
					contaLogin = menuAdministrativoView.loginAdministrativo();
					if (contaLogin == null) {
						// caso a contaLogin seja nula será exibida uma mensagem de erro, e o
						// menuAdministrativo NÃO será acessado
						System.out.println(
								"╔═════════════════════════════════════════════════════════════════════════════════════╗");
						System.out.println(
								"║  (｡•́︿•̀｡) As credenciais fornecidas não correspondem a uma conta existente (｡•́︿•̀｡)   ║");
						System.out.println(
								"╚═════════════════════════════════════════════════════════════════════════════════════╝");
						break;
					}

					else {
						menuAdministrativoView.menuAdministrativo(contaLogin);
						break;
					}
				}

				break;
			case 2:
				while (acessoSaude == true) {
					contaLogin = menuProfissionalSaude.loginProfissionalSaude();
					if (contaLogin == null) {
						// caso a contaLogin seja nula será exibida uma mensagem de erro, e o
						// menuAdministrativo NÃO será acessado
						System.out.println(
								"╔═════════════════════════════════════════════════════════════════════════════════════╗");
						System.out.println(
								"║  (｡•́︿•̀｡) As credenciais fornecidas não correspondem a uma conta existente (｡•́︿•̀｡)   ║");
						System.out.println(
								"╚═════════════════════════════════════════════════════════════════════════════════════╝");
						break;
					}

					else {
						menuProfissionalSaude.menuProfissionalSaude(contaLogin);
						break;
					}
				}
				break;
			case 3:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║    (˵ •̀ ᴗ - ˵ ) ✧  Encerrando Juno...                     ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
				menuPrincipal = false;
				break;

			default:
				System.out.println("╔═══════════════════════════════════════════════════════════╗");
				System.out.println("║  (｡•́︿•̀｡)   Opção Inválida! Selecione novamente  (｡•́︿•̀｡)   ║");
				System.out.println("╚═══════════════════════════════════════════════════════════╝");
			}

		}
	}

}
