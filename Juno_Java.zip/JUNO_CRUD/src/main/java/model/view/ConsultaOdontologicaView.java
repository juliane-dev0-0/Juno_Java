package model.view;

import java.util.Scanner;
import java.util.Date;
import model.controller.ConsultaOdontologicaController;
import model.entities.Paciente;
import model.entities.ProtocoloPreNatal;
import model.entities.ConsultaOdontologica;

public class ConsultaOdontologicaView {

	private ConsultaOdontologicaController consultaOdontologicaController;
	private Scanner scanner;

	public ConsultaOdontologicaView() {
		this.consultaOdontologicaController = new ConsultaOdontologicaController();
		this.scanner = new Scanner(System.in);
	}

	public void adicionarConsultaOdontologica(Paciente paciente, ProtocoloPreNatal protocolo) {
		try {
			System.out.println("Adicionando nova Consulta Odontologica");

			System.out.print("Data do Atendimento (AAAA-MM-DD): ");
			String dataTesteStr = scanner.nextLine();
			Date dataTeste = java.sql.Date.valueOf(dataTesteStr);

			System.out.print("Descrição: ");
			String descricao = scanner.nextLine();

			// Criando o objeto teste rápido
			ConsultaOdontologica consultaOdontologica = new ConsultaOdontologica();
			consultaOdontologica.setDataAtendimento(dataTeste);
			consultaOdontologica.setDescricao(descricao);

			// Definindo o paciente e protocolo associados ao teste
			consultaOdontologica.setPacienteConsultado(paciente);
			consultaOdontologica.setProtocoloPertencente(protocolo);

			// Chamando o controlador para adicionar o teste rápido
			ConsultaOdontologica novoConsultaOdontologica = consultaOdontologicaController
					.adicionarConsultaOdontologica(consultaOdontologica);
			System.out.println("Consulta Odontologica adicionada com sucesso! ID do teste: "
					+ novoConsultaOdontologica.getIdConsultaOdontologica());

		} catch (Exception e) {
			System.out.println("Erro ao adicionar consulta: " + e.getMessage());
		}
	}

	public static void main(String[] args) {
		ConsultaOdontologicaView view = new ConsultaOdontologicaView();

		// Supondo que já temos um paciente e um protocolo criados
		Paciente paciente = new Paciente();
		paciente.setIdPaciente(1L); // Supostamente o paciente com ID 1 já existe no sistema

		ProtocoloPreNatal protocolo = new ProtocoloPreNatal();
		protocolo.setIdProtocolo(1L); // Supostamente o protocolo com ID 1 já existe no sistema

		// Adicionando um novo teste rápido associado ao paciente e protocolo
		view.adicionarConsultaOdontologica(paciente, protocolo);
	}
}
