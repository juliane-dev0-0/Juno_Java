package model.entities;

import javax.persistence.*;

@Entity
@Table(name = "niveis_urgencia")
public class NiveisUrgencia {
	// só ha 3 opções entao nao ha pq um id auto
	@Id
	@Column(name = "id_niveis_urgencia")
	private Long idUrgencia;

	@Column(name = "descricao", length = 500) // varchar(500)
	private String descricao;

	public Long getIdUrgencia() {
		return idUrgencia;
	}

	public void setIdUrgencia(Long idUrgencia) {
		this.idUrgencia = idUrgencia;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public NiveisUrgencia() {
	}

	public NiveisUrgencia(Long idUrgencia, String descricao) {
		super();
		this.idUrgencia = idUrgencia;
		this.descricao = descricao;
	}

}
