package model.entities;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "protocolo_prenatal")
public class ProtocoloPreNatal {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_protocolo_prenatal")
	private Long idProtocolo;

	@Column(nullable = false, name = "data_abertura")
	private Date dataAbertura;
	@Column(name = "abertura_aprovada")
	private boolean aberturaAprovada;
	@Column(name = "data_encerramento")
	private Date dataEncerramento;
	@Column(name = "status_protocolo")
	private int statusProtocolo;
	@Column(name = "dum", nullable = false)
	private Date dum;
	@Column(name = "dpp", nullable = false)
	private Date dpp;
	@Column(name = "num_testes_rapidos")
	private int numTestesRapidos;
	@Column(name = "num_consultas_odontologicas")
	private int numConsultasOdontologicas;

	@ManyToOne
	@JoinColumn(name = "FK_id_paciente", nullable = false)
	private Paciente paciente;

	public Long getIdProtocolo() {
		return idProtocolo;
	}

	public void setIdProtocolo(Long idProtocolo) {
		this.idProtocolo = idProtocolo;
	}

	public Date getDataAbertura() {
		return dataAbertura;
	}

	public void setDataAbertura(Date dataAbertura) {
		this.dataAbertura = dataAbertura;
	}

	public boolean isAberturaAprovada() {
		return aberturaAprovada;
	}

	public void setAberturaAprovada(boolean aberturaAprovada) {
		this.aberturaAprovada = aberturaAprovada;
	}

	public Date getDataEncerramento() {
		return dataEncerramento;
	}

	public void setDataEncerramento(Date dataEncerramento) {
		this.dataEncerramento = dataEncerramento;
	}

	public int getStatusProtocolo() {
		return statusProtocolo;
	}

	public void setStatusProtocolo(int statusProtocolo) {
		this.statusProtocolo = statusProtocolo;
	}

	public Date getDum() {
		return dum;
	}

	public void setDum(Date dum) {
		this.dum = dum;
	}

	public Date getDpp() {
		return dpp;
	}

	public void setDpp(Date dpp) {
		this.dpp = dpp;
	}

	public int getNumTestesRapidos() {
		return numTestesRapidos;
	}

	public void setNumTestesRapidos(int numTestesRapidos) {
		this.numTestesRapidos = numTestesRapidos;
	}

	public int getNumConsultasOdontologicas() {
		return numConsultasOdontologicas;
	}

	public void setNumConsultasOdontologicas(int numConsultasOdontologicas) {
		this.numConsultasOdontologicas = numConsultasOdontologicas;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public ProtocoloPreNatal(Long idProtocolo, Date dataAbertura, boolean aberturaAprovada, Date dataEncerramento,
			int statusProtocolo, Date dum, Date dpp, int numTestesRapidos, int numConsultasOdontologicas,
			Paciente paciente) {
		super();
		this.idProtocolo = idProtocolo;
		this.dataAbertura = dataAbertura;
		this.aberturaAprovada = aberturaAprovada;
		this.dataEncerramento = dataEncerramento;
		this.statusProtocolo = statusProtocolo;
		this.dum = dum;
		this.dpp = dpp;
		this.numTestesRapidos = numTestesRapidos;
		this.numConsultasOdontologicas = numConsultasOdontologicas;
		this.paciente = paciente;
	}

	public ProtocoloPreNatal() {
	}

}
