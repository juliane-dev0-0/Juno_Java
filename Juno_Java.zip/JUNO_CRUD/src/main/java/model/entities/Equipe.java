package model.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "equipe")
public class Equipe {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_equipe")
	private Long idEquipe;

	@Column(nullable = false, name = "nome", length = 90)
	private String nome;

	@Column(name = "descricao", length = 200)
	private String descricao;

	// Novos atributos para chaves estrangeiras
	@Column(name = "nome_usuario", length = 45)
	private String nomeUsuario;

	@Column(name = "nome_paciente", length = 45)
	private String nomePaciente;

	// Getter and setter for nomePaciente
	public String getNomePaciente() {
		return nomePaciente;
	}

	public void setNomePaciente(String nomePaciente) {
		this.nomePaciente = nomePaciente;
	}

	public Long getIdEquipe() {
		return idEquipe;
	}

	public void setIdEquipe(Long idEquipe) {
		this.idEquipe = idEquipe;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	// Métodos getter e setter para nomeUsuario
	public String getNomeUsuario() {
		return nomeUsuario;
	}

	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}

	public Equipe() {
	}

	public Equipe(Long idEquipe, String nome, String descricao, String nomeUsuario, String nomePaciente) {
		this.idEquipe = idEquipe;
		this.nome = nome;
		this.descricao = descricao;
		this.nomeUsuario = nomeUsuario;
		this.nomePaciente = nomePaciente;
	}
}
