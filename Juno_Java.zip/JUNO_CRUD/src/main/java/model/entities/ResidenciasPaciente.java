package model.entities;

import javax.persistence.*;

@Entity
@Table(name = "residencias_paciente")
public class ResidenciasPaciente {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_residencias_paciente")
	private Long idResidencia;

	@ManyToOne
	@JoinColumn(name = "FK_id_paciente", nullable = false)
	private Paciente paciente;

	@ManyToOne
	@JoinColumn(name = "FK_endereco", nullable = false)
	private Endereco endereco;

	public Long getIdResidencia() {
		return idResidencia;
	}

	public void setIdResidencia(Long idResidencia) {
		this.idResidencia = idResidencia;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public ResidenciasPaciente(Long idResidencia, Paciente paciente, Endereco endereco) {
		super();
		this.idResidencia = idResidencia;
		this.paciente = paciente;
		this.endereco = endereco;
	}

	public ResidenciasPaciente() {
	}

}
