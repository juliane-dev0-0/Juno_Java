package model.entities;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "consulta_odontologica")
public class ConsultaOdontologica {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_consulta_odontologica")
	private Long idConsultaOdontologica;

	@Column(nullable = false, name = "data_atendimento")
	private Date dataAtendimento;

	@ManyToOne
	@JoinColumn(name = "FK_protocolo_pertencente", nullable = false)
	private ProtocoloPreNatal protocoloPertencente;

	@ManyToOne
	@JoinColumn(name = "FK_paciente_consultado", nullable = false)
	private Paciente pacienteConsultado;

	@Column(name = "descricao")
	private String descricao;

	public Long getIdConsultaOdontologica() {
		return idConsultaOdontologica;
	}

	public void setIdConsultaOdontologica(Long idConsultaOdontologica) {
		this.idConsultaOdontologica = idConsultaOdontologica;
	}

	public Date getDataAtendimento() {
		return dataAtendimento;
	}

	public void setDataAtendimento(Date dataAtendimento) {
		this.dataAtendimento = dataAtendimento;
	}

	public ProtocoloPreNatal getProtocoloPertencente() {
		return protocoloPertencente;
	}

	public void setProtocoloPertencente(ProtocoloPreNatal protocoloPertencente) {
		this.protocoloPertencente = protocoloPertencente;
	}

	public Paciente getPacienteConsultado() {
		return pacienteConsultado;
	}

	public void setPacienteConsultado(Paciente pacienteConsultado) {
		this.pacienteConsultado = pacienteConsultado;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public ConsultaOdontologica(Long idConsultaOdontologica, Date dataAtendimento,
			ProtocoloPreNatal protocoloPertencente, Paciente pacienteConsultado, String descricao) {
		super();
		this.idConsultaOdontologica = idConsultaOdontologica;
		this.dataAtendimento = dataAtendimento;
		this.protocoloPertencente = protocoloPertencente;
		this.pacienteConsultado = pacienteConsultado;
		this.descricao = descricao;
	}

	public ConsultaOdontologica() {
	}

}
