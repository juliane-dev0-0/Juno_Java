package model.entities;

import javax.persistence.*;

@Entity
@Table(name = "endereco")
public class Endereco {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_endereco")
	private Long idEndereco;

	@Column(name = "cep", nullable = false)
	private String cep;

	@Column(name = "pais", nullable = false)
	private String pais;

	@Column(name = "uf", nullable = false)
	private String uf;

	@Column(name = "cidade", nullable = false)
	private String cidade;

	@Column(name = "logradouro")
	private String logradouro;

	@Column(name = "numero")
	private String numero;

	@Column(name = "descricao")
	private String descricao;

	public Long getIdEndereco() {
		return idEndereco;
	}

	public void setIdEndereco(Long idEndereco) {
		this.idEndereco = idEndereco;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Endereco() {
	}

	public Endereco(Long idEndereco, String cep, String pais, String uf, String cidade, String logradouro,
			String numero, String descricao) {
		super();
		this.idEndereco = idEndereco;
		this.cep = cep;
		this.pais = pais;
		this.uf = uf;
		this.cidade = cidade;
		this.logradouro = logradouro;
		this.numero = numero;
		this.descricao = descricao;
	}

}
