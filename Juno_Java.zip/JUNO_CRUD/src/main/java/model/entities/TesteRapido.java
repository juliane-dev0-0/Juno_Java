package model.entities;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "teste_rapido")
public class TesteRapido {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_teste_rapido")
	private Long idTesteRapido;

	@Column(nullable = false, name = "data_teste")
	private Date dataTeste;

	@ManyToOne
	@JoinColumn(name = "FK_protocolo_pertencente", nullable = false)
	private ProtocoloPreNatal protocoloPertencente;

	@ManyToOne
	@JoinColumn(name = "FK_paciente_consultado", nullable = false)
	private Paciente pacienteConsultado;

	@Column(nullable = false, name = "exame_sangue")
	private int exameSangue;

	@Column(nullable = false, name = "exame_urina")
	private int exameUrina;

	@Column(name = "descricao")
	private String descricao;

	public Long getIdTesteRapido() {
		return idTesteRapido;
	}

	public void setIdTesteRapido(Long idTesteRapido) {
		this.idTesteRapido = idTesteRapido;
	}

	public Date getDataTeste() {
		return dataTeste;
	}

	public void setDataTeste(Date dataTeste) {
		this.dataTeste = dataTeste;
	}

	public ProtocoloPreNatal getProtocoloPertencente() {
		return protocoloPertencente;
	}

	public void setProtocoloPertencente(ProtocoloPreNatal protocoloPertencente) {
		this.protocoloPertencente = protocoloPertencente;
	}

	public Paciente getPacienteConsultado() {
		return pacienteConsultado;
	}

	public void setPacienteConsultado(Paciente pacienteConsultado) {
		this.pacienteConsultado = pacienteConsultado;
	}

	public int getExameSangue() {
		return exameSangue;
	}

	public void setExameSangue(int exameSangue) {
		this.exameSangue = exameSangue;
	}

	public int getExameUrina() {
		return exameUrina;
	}

	public void setExameUrina(int exameUrina) {
		this.exameUrina = exameUrina;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public TesteRapido(Long idTesteRapido, Date dataTeste, ProtocoloPreNatal protocoloPertencente,
			Paciente pacienteConsultado, int exameSangue, int exameUrina, String descricao) {
		super();
		this.idTesteRapido = idTesteRapido;
		this.dataTeste = dataTeste;
		this.protocoloPertencente = protocoloPertencente;
		this.pacienteConsultado = pacienteConsultado;
		this.exameSangue = exameSangue;
		this.exameUrina = exameUrina;
		this.descricao = descricao;
	}

	public TesteRapido() {
	}
}
