package model.entities;

import javax.persistence.*;

@Entity
@Table(name = "conta")
public class Conta {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_conta")
	private Long idConta;
	@ManyToOne
	@JoinColumn(name = "FK_id_usuario_gerente", nullable = false)
	private Usuario gerente;

	@ManyToOne
	@JoinColumn(name = "FK_role", nullable = false)
	private ContaRole role;

	@ManyToOne
	@JoinColumn(name = "FK_publico", nullable = false)
	private Publico publico;

	@ManyToOne
	@JoinColumn(name = "FK_equipe", nullable = false)
	private Equipe equipe;

	// Construtor padrão
	public Conta() {
	}

	// Construtor com parâmetros
	public Conta(Long idConta, Usuario gerente, ContaRole role, Publico publico, Equipe equipe) {
		this.idConta = idConta;
		this.gerente = gerente;
		this.role = role;
		this.publico = publico;
		this.equipe = equipe;
	}

	// Getters e Setters

	public Long getIdConta() {
		return idConta;
	}

	public void setIdConta(Long idConta) {
		this.idConta = idConta;
	}

	public Usuario getGerente() {
		return gerente;
	}

	public void setGerente(Usuario gerente) {
		this.gerente = gerente;
	}

	public ContaRole getRole() {
		return role;
	}

	public void setRole(ContaRole role) {
		this.role = role;
	}

	public Publico getPublico() {
		return publico;
	}

	public void setPublico(Publico publico) {
		this.publico = publico;
	}

	public Equipe getEquipe() {
		return equipe;
	}

	public void setEquipe(Equipe equipe) {
		this.equipe = equipe;
	}
}
