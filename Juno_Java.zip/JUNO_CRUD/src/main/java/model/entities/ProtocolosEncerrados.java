package model.entities;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "protocolos_encerrados")
public class ProtocolosEncerrados {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_protocolos_encerrados")
	private Long idProtocoloEncerrado;

	@Column(nullable = false, name = "id_original_protocolo")
	private Long idOriginalProtocolo;

	@Column(nullable = false, name = "data_abertura")
	private Date dataAbertura;

	@ManyToOne
	@JoinColumn(name = "FK_id_gestante", nullable = false)
	private Paciente gestante;

	@Column(name = "data_encerramento")
	private Date dataEncerramento;

	public Long getIdProtocoloEncerrado() {
		return idProtocoloEncerrado;
	}

	public void setIdProtocoloEncerrado(Long idProtocoloEncerrado) {
		this.idProtocoloEncerrado = idProtocoloEncerrado;
	}

	public Long getIdOriginalProtocolo() {
		return idOriginalProtocolo;
	}

	public void setIdOriginalProtocolo(Long idOriginalProtocolo) {
		this.idOriginalProtocolo = idOriginalProtocolo;
	}

	public Date getDataAbertura() {
		return dataAbertura;
	}

	public void setDataAbertura(Date dataAbertura) {
		this.dataAbertura = dataAbertura;
	}

	public Paciente getGestante() {
		return gestante;
	}

	public void setGestante(Paciente gestante) {
		this.gestante = gestante;
	}

	public Date getDataEncerramento() {
		return dataEncerramento;
	}

	public void setDataEncerramento(Date dataEncerramento) {
		this.dataEncerramento = dataEncerramento;
	}

	public ProtocolosEncerrados(Long idProtocoloEncerrado, Long idOriginalProtocolo, Date dataAbertura,
			Paciente gestante, Date dataEncerramento) {
		super();
		this.idProtocoloEncerrado = idProtocoloEncerrado;
		this.idOriginalProtocolo = idOriginalProtocolo;
		this.dataAbertura = dataAbertura;
		this.gestante = gestante;
		this.dataEncerramento = dataEncerramento;
	}

	public ProtocolosEncerrados() {
	}
}
