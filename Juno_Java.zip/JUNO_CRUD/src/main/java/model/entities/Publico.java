package model.entities;

import javax.persistence.*;

@Entity
@Table(name = "publico")
public class Publico {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_publico")
	private Long idPublico;

	@Column(nullable = false, name = "nome", length = 45) // varchar(45)
	private String nome;

	@Column(name = "descricao", length = 500) // varchar(200)
	private String descricao;

	public Long getIdPublico() {
		return idPublico;
	}

	public void setIdPublico(Long idPublico) {
		this.idPublico = idPublico;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Publico() {
	}

	public Publico(Long idPublico, String nome, String descricao) {
		super();
		this.idPublico = idPublico;
		this.nome = nome;
		this.descricao = descricao;
	}

}
