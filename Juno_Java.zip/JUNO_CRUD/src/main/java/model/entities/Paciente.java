package model.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "paciente")
public class Paciente {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_paciente")
	private Long idPaciente;

	@Column(name = "nome", nullable = false)
	private String nome;

	@Column(name = "rg")
	private String rg;

	@Column(name = "cpf")
	private String cpf;

	@Column(name = "data_nascimento", nullable = false)
	private Date data_nascimento;

	@Column(name = "tipo_sanguineo")
	private String tipoSanguineo;

	@Column(name = "status_prenatal")
	private String statusPreNatal;

	@Column(name = "telefone")
	private String telefone;

	@Column(name = "cep")
	private String cep;

	@Column(name = "estado")
	private String estado;

	@Column(name = "cidade")
	private String cidade;

	@Column(name = "bairro")
	private String bairro;

	@Column(name = "num")
	private Integer num;

	@Column(name = "logradouro")
	private String logradouro;

	@Column(name = "endereco")
	private String endereco;

	@ManyToOne
	@JoinColumn(name = "FK_equipe_responsavel", nullable = false)
	private Equipe equipeResponsavel;

	// Constructors, getters, and setters
	public Paciente(Long idPaciente, String nome, String rg, String cpf, Date data_nascimento, String tipoSanguineo,
			String statusPreNatal, String telefone, Equipe equipeResponsavel, String cep, String estado, String cidade,
			String bairro, int num, String logradouro, String endereco) {
		this.idPaciente = idPaciente;
		this.nome = nome;
		this.rg = rg;
		this.cpf = cpf;
		this.data_nascimento = data_nascimento;
		this.tipoSanguineo = tipoSanguineo;
		this.statusPreNatal = statusPreNatal;
		this.telefone = telefone;
		this.equipeResponsavel = equipeResponsavel;
		this.cep = cep;
		this.estado = estado;
		this.cidade = cidade;
		this.bairro = bairro;
		this.num = num;
		this.logradouro = logradouro;
		this.endereco = endereco;
	}

	public Paciente(String nome, String rg, String cpf, Date data_nascimento, String tipoSanguineo,
			String statusPreNatal, String telefone, Equipe equipeResponsavel, String cep, String estado, String cidade,
			String bairro, int num, String logradouro, String endereco) {
		this.nome = nome;
		this.rg = rg;
		this.cpf = cpf;
		this.data_nascimento = data_nascimento;
		this.tipoSanguineo = tipoSanguineo;
		this.statusPreNatal = statusPreNatal;
		this.telefone = telefone;
		this.equipeResponsavel = equipeResponsavel;
		this.cep = cep;
		this.estado = estado;
		this.cidade = cidade;
		this.bairro = bairro;
		this.num = num;
		this.logradouro = logradouro;
		this.endereco = endereco;
	}

	public Paciente() {
	}

	public Long getIdPaciente() {
		return idPaciente;
	}

	public void setIdPaciente(Long idPaciente) {
		this.idPaciente = idPaciente;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Date getDataNascimento() {
		return data_nascimento;
	}

	public void setDataNascimento(Date data_nascimento) {
		this.data_nascimento = data_nascimento;
	}

	public String getTipoSanguineo() {
		return tipoSanguineo;
	}

	public void setTipoSanguineo(String tipoSanguineo) {
		this.tipoSanguineo = tipoSanguineo;
	}

	public String getStatusPreNatal() {
		return statusPreNatal;
	}

	public void setStatusPreNatal(String statusPreNatal) {
		this.statusPreNatal = statusPreNatal;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public Equipe getEquipeResponsavel() {
		return equipeResponsavel;
	}

	public void setEquipeResponsavel(Equipe equipeResponsavel) {
		this.equipeResponsavel = equipeResponsavel;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public Integer getNum() {
		return num;
	}

	public void setNum(Integer num) {
		this.num = num;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
}
