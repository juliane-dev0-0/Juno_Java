package model.service;

import java.util.List;

import model.entities.Equipe;
import model.entities.Paciente;
import model.repositories.EquipeRepository;
import model.repositories.PacienteRepository;

public class PacienteService {

	private PacienteRepository pacienteRepository;
	private EquipeRepository equipeRepository;

	public PacienteService() {
		this.pacienteRepository = new PacienteRepository();
		this.equipeRepository = new EquipeRepository();
	}

	public Paciente adicionarPaciente(Paciente paciente) {
		Equipe equipe = (Equipe) equipeRepository.findById(paciente.getEquipeResponsavel().getIdEquipe());

		if (equipe == null) {
			throw new IllegalArgumentException("Equipe não encontrada");
		}

		paciente.setEquipeResponsavel(equipe);
		return (Paciente) pacienteRepository.create(paciente);
	}

	public Paciente obterPacientePorId(Long id) {
		return (Paciente) pacienteRepository.findById(id);
	}

	public Paciente obterPacientePorNome(String nome) {
		return pacienteRepository.findByName(nome);
	}

	public Paciente atualizarPaciente(Paciente paciente) {
		return (Paciente) pacienteRepository.updateById(paciente);
	}

	public void deletarPaciente(Long id) {
		pacienteRepository.delete(id);
	}

	public List<Paciente> obterTodosPacientes() {
		return pacienteRepository.findAll();
	}

}
