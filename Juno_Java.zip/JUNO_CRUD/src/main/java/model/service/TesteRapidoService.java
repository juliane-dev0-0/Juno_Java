package model.service;

import java.util.List;
import model.entities.Paciente;
import model.entities.ProtocoloPreNatal;
import model.entities.TesteRapido;
import model.repositories.PacienteRepository;
import model.repositories.ProtocoloPreNatalRepository;
import model.repositories.TesteRapidoRepository;

public class TesteRapidoService {
	private ProtocoloPreNatalRepository protocoloPreNatalRepository;
	private PacienteRepository pacienteRepository;
	private TesteRapidoRepository testeRapidoRepository;

	public TesteRapidoService() {
		this.protocoloPreNatalRepository = new ProtocoloPreNatalRepository();
		this.pacienteRepository = new PacienteRepository();
		this.testeRapidoRepository = new TesteRapidoRepository();
	}

	// validação das entidades
	public TesteRapido adicionarTesteRapido(TesteRapido testeRapido) {
		Paciente paciente = (Paciente) pacienteRepository.findById(testeRapido.getPacienteConsultado().getIdPaciente());
		ProtocoloPreNatal protocolo = (ProtocoloPreNatal) protocoloPreNatalRepository
				.findById(testeRapido.getProtocoloPertencente().getIdProtocolo());

		if (paciente == null || protocolo == null) {
			throw new IllegalArgumentException("Uma ou mais entidades não foram encontradas.");
		}
		testeRapido.setPacienteConsultado(paciente);
		testeRapido.setProtocoloPertencente(protocolo);
		return (TesteRapido) testeRapidoRepository.create(testeRapido);
	}

	public TesteRapido obterTesteRapidoPorId(Long id) {
		return (TesteRapido) testeRapidoRepository.findById(id);
	}

	public TesteRapido atualizarTesteRapido(TesteRapido testeRapido) {
		return (TesteRapido) testeRapidoRepository.updateById(testeRapido);
	}

	public void deletarTesteRapido(Long id) {
		testeRapidoRepository.delete(id);
	}

	public List<TesteRapido> obterTodosTesteRapidos() {
		return testeRapidoRepository.findAll();
	}

}
