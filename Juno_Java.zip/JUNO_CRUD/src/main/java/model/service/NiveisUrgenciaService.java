package model.service;

import java.util.List;

import model.entities.*;
import model.repositories.NiveisUrgenciaRepository;

public class NiveisUrgenciaService {

	private NiveisUrgenciaRepository niveisUrgenciaRepository;

	// LOGICAS DE NEGOCIOS NO SERVICE INTERAGEM COM O REPOSITORY
	public NiveisUrgenciaService() {
		this.niveisUrgenciaRepository = new NiveisUrgenciaRepository();
	}

	public NiveisUrgencia adicionarNiveisUrgencia(NiveisUrgencia niveisUrgencia) {

		return (NiveisUrgencia) niveisUrgenciaRepository.create(niveisUrgencia);
	}

	public NiveisUrgencia obterNiveisUrgenciaPorId(Long id) {
		return (NiveisUrgencia) niveisUrgenciaRepository.findById(id);
	}

	public NiveisUrgencia atualizarNiveisUrgencia(NiveisUrgencia niveisUrgencia) {
		return (NiveisUrgencia) niveisUrgenciaRepository.updateById(niveisUrgencia);
	}

	public void deletarNiveisUrgencia(Long id) {
		niveisUrgenciaRepository.delete(id);
	}

	public List<NiveisUrgencia> obterTodosNiveisUrgencias() {
		return niveisUrgenciaRepository.findAll();
	}
}
