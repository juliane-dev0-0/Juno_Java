package model.service;

import java.util.List;

import model.entities.Equipe;
import model.repositories.EquipeRepository;

public class EquipeService {

	private EquipeRepository equipeRepository;

	// LOGICAS DE NEGOCIOS NO SERVICE INTERAGEM COM O REPOSITORY
	public EquipeService() {
		this.equipeRepository = new EquipeRepository();
	}

	public Equipe adicionarEquipe(Equipe equipe) {

		return (Equipe) equipeRepository.create(equipe);
	}

	public Equipe obterEquipePorId(Long id) {
		return (Equipe) equipeRepository.findById(id);
	}

	public Equipe atualizarEquipe(Equipe equipe) {
		return (Equipe) equipeRepository.updateById(equipe);
	}

	public void deletarEquipe(Long id) {
		equipeRepository.delete(id);
	}

	public List<Equipe> obterTodosEquipes() {
		return equipeRepository.findAll();
	}
}
