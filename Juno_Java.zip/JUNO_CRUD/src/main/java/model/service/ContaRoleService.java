package model.service;

import java.util.List;

import model.entities.ContaRole;
import model.repositories.ContaRoleRepository;

public class ContaRoleService {
	private ContaRoleRepository contaRoleRepository;

	// LOGICAS DE NEGOCIOS NO SERVICE INTERAGEM COM O REPOSITORY
	public ContaRoleService() {
		this.contaRoleRepository = new ContaRoleRepository();
	}

	public ContaRole adicionarContaRole(ContaRole contaRole) {
		// if(contaRoleRepository.isEmailInUse(contaRole.getEmail())) {
		// throw new RuntimeException("Email já cadastrado!");
		// }
		return (ContaRole) contaRoleRepository.create(contaRole);
	}

	public ContaRole obterContaRolePorId(Long id) {
		return (ContaRole) contaRoleRepository.findById(id);
	}

	public ContaRole atualizarContaRole(ContaRole contaRole) {
		return (ContaRole) contaRoleRepository.updateById(contaRole);
	}

	public void deletarContaRole(Long id) {
		contaRoleRepository.delete(id);
	}

	public List<ContaRole> obterTodosContaRoles() {
		return contaRoleRepository.findAll();
	}
}
