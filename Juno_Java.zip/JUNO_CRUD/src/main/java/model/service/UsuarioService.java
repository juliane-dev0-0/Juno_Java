package model.service;

import java.util.List;

import model.entities.Usuario;
import model.repositories.UsuarioRepository;

public class UsuarioService {
	private UsuarioRepository usuarioRepository;

	// LOGICAS DE NEGOCIOS NO SERVICE INTERAGEM COM O REPOSITORY
	public UsuarioService() {
		this.usuarioRepository = new UsuarioRepository();
	}

	public Usuario adicionarUsuario(Usuario usuario) {
		// if(usuarioRepository.isEmailInUse(usuario.getEmail())) {
		// throw new RuntimeException("Email já cadastrado!");
		// }
		return (Usuario) usuarioRepository.create(usuario);
	}

	public Usuario obterUsuarioPorId(Long id) {
		return (Usuario) usuarioRepository.findById(id);
	}

	public Usuario atualizarUsuario(Usuario usuario) {
		return (Usuario) usuarioRepository.updateById(usuario);
	}

	public void deletarUsuario(Long id) {
		usuarioRepository.delete(id);
	}

	public List<Usuario> obterTodosUsuarios() {
		return usuarioRepository.findAll();
	}
}
