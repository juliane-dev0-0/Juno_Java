package model.service;

import java.util.List;

import model.entities.*;
import model.repositories.ContaRepository;
import model.repositories.ContaRoleRepository;
import model.repositories.EquipeRepository;
import model.repositories.PublicoRepository;
import model.repositories.UsuarioRepository;

public class ContaService {

	private ContaRepository contaRepository;
	private UsuarioRepository usuarioRepository;
	private ContaRoleRepository contaRoleRepository;
	private PublicoRepository publicoRepository;
	private EquipeRepository equipeRepository;

	// LOGICAS DE NEGOCIOS NO SERVICE INTERAGEM COM O REPOSITORY
	public ContaService() {
		this.contaRepository = new ContaRepository();

		this.usuarioRepository = new UsuarioRepository();
		this.contaRoleRepository = new ContaRoleRepository();
		this.publicoRepository = new PublicoRepository();
		this.equipeRepository = new EquipeRepository();

	}

//este bloco de codigo garante que as entidades existem antes de criar uma nova conta
	public Conta adicionarConta(Conta conta) {
		// resgata as entidades relacionadas do banco de dados
		Usuario gerente = (Usuario) usuarioRepository.findById(conta.getGerente().getId());
		ContaRole role = (ContaRole) contaRoleRepository.findById(conta.getRole().getId());
		Publico publico = (Publico) publicoRepository.findById(conta.getPublico().getIdPublico());
		Equipe equipe = (Equipe) equipeRepository.findById(conta.getEquipe().getIdEquipe());

		if (gerente == null || role == null || publico == null || equipe == null) {
			throw new IllegalArgumentException("Uma ou mais entidades não foram encontradas.");
		}

		conta.setGerente(gerente);
		conta.setRole(role);
		conta.setPublico(publico);
		conta.setEquipe(equipe);

		return (Conta) contaRepository.create(conta);
	}

	public Conta obterContaPorId(Long id) {
		return (Conta) contaRepository.findById(id);
	}

	public Conta atualizarConta(Conta conta) {
		return (Conta) contaRepository.updateById(conta);
	}

	public void deletarConta(Long id) {
		contaRepository.delete(id);
	}

	public List<Conta> obterTodosContas() {
		return contaRepository.findAll();
	}

}
