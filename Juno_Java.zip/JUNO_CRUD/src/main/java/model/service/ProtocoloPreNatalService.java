package model.service;

import java.util.List;

import model.entities.Paciente;
import model.entities.ProtocoloPreNatal;
import model.repositories.PacienteRepository;
import model.repositories.ProtocoloPreNatalRepository;

public class ProtocoloPreNatalService {

	private ProtocoloPreNatalRepository protocoloPreNatalRepository;
	private PacienteRepository pacienteRepository;

	public ProtocoloPreNatalService() {
		this.protocoloPreNatalRepository = new ProtocoloPreNatalRepository();
		this.pacienteRepository = new PacienteRepository();
	}

	// este bloco de codigo garante que as entidades existem antes de criar
	public ProtocoloPreNatal adicionarProtocoloPreNatal(ProtocoloPreNatal protocoloPreNatal) {
		Paciente paciente = (Paciente) pacienteRepository.findById(protocoloPreNatal.getPaciente().getIdPaciente());

		if (paciente == null) {
			throw new IllegalArgumentException("Uma ou mais entidades não foram encontradas.");
		}
		protocoloPreNatal.setPaciente(paciente);
		return (ProtocoloPreNatal) protocoloPreNatalRepository.create(protocoloPreNatal);
	}

	public ProtocoloPreNatal obterProtocoloPreNatalPorId(Long id) {
		return (ProtocoloPreNatal) protocoloPreNatalRepository.findById(id);
	}

	public ProtocoloPreNatal atualizarProtocoloPreNatal(ProtocoloPreNatal protocoloPreNatal) {
		return (ProtocoloPreNatal) protocoloPreNatalRepository.updateById(protocoloPreNatal);
	}

	public void deletarProtocoloPreNatal(Long id) {
		protocoloPreNatalRepository.delete(id);
	}

	public List<ProtocoloPreNatal> obterTodosProtocoloPreNatals() {
		return protocoloPreNatalRepository.findAll();

	}
}
