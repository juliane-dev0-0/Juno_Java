package model.service;

import java.util.List;

import model.entities.Paciente;
import model.entities.ProtocolosEncerrados;
import model.repositories.PacienteRepository;
import model.repositories.ProtocolosEncerradosRepository;

public class ProtocolosEncerradosService {

	private ProtocolosEncerradosRepository protocolosEncerradosRepository;
	private PacienteRepository pacienteRepository;

	public ProtocolosEncerradosService() {
		this.protocolosEncerradosRepository = new ProtocolosEncerradosRepository();
		this.pacienteRepository = new PacienteRepository();
	}

	// este bloco de codigo garante que as entidades existem antes de criar
	public ProtocolosEncerrados adicionarProtocolosEncerrados(ProtocolosEncerrados protocolosEncerrados) {
		Paciente paciente = (Paciente) pacienteRepository.findById(protocolosEncerrados.getGestante().getIdPaciente());

		if (paciente == null) {
			throw new IllegalArgumentException("Uma ou mais entidades não foram encontradas.");
		}
		protocolosEncerrados.setGestante(paciente);
		return (ProtocolosEncerrados) protocolosEncerradosRepository.create(protocolosEncerrados);
	}

	public ProtocolosEncerrados obterProtocolosEncerradosPorId(Long id) {
		return (ProtocolosEncerrados) protocolosEncerradosRepository.findById(id);
	}

	public ProtocolosEncerrados atualizarProtocolosEncerrados(ProtocolosEncerrados protocolosEncerrados) {
		return (ProtocolosEncerrados) protocolosEncerradosRepository.updateById(protocolosEncerrados);
	}

	public void deletarProtocolosEncerrados(Long id) {
		protocolosEncerradosRepository.delete(id);
	}

	public List<ProtocolosEncerrados> obterTodosProtocolosEncerradoss() {
		return protocolosEncerradosRepository.findAll();

	}
}
