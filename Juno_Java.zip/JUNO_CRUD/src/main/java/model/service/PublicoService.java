package model.service;

import java.util.List;

import model.entities.*;
import model.repositories.PublicoRepository;

public class PublicoService {

	private PublicoRepository publicoRepository;

	// LOGICAS DE NEGOCIOS NO SERVICE INTERAGEM COM O REPOSITORY
	public PublicoService() {
		this.publicoRepository = new PublicoRepository();
	}

	public Publico adicionarPublico(Publico publico) {

		return (Publico) publicoRepository.create(publico);
	}

	public Publico obterPublicoPorId(Long id) {
		return (Publico) publicoRepository.findById(id);
	}

	public Publico atualizarPublico(Publico publico) {
		return (Publico) publicoRepository.updateById(publico);
	}

	public void deletarPublico(Long id) {
		publicoRepository.delete(id);
	}

	public List<Publico> obterTodosPublicos() {
		return publicoRepository.findAll();
	}
}
