package model.service;

import java.util.List;
import model.entities.Paciente;
import model.entities.ProtocoloPreNatal;
import model.entities.ConsultaOdontologica;
import model.repositories.PacienteRepository;
import model.repositories.ProtocoloPreNatalRepository;
import model.repositories.ConsultaOdontologicaRepository;

public class ConsultaOdontologicaService {
	private ProtocoloPreNatalRepository protocoloPreNatalRepository;
	private PacienteRepository pacienteRepository;
	private ConsultaOdontologicaRepository consultaOdontologicaRepository;

	public ConsultaOdontologicaService() {
		this.protocoloPreNatalRepository = new ProtocoloPreNatalRepository();
		this.pacienteRepository = new PacienteRepository();
		this.consultaOdontologicaRepository = new ConsultaOdontologicaRepository();
	}

	// validação das entidadesF
	public ConsultaOdontologica adicionarConsultaOdontologica(ConsultaOdontologica consultaOdontologica) {
		Paciente paciente = (Paciente) pacienteRepository
				.findById(consultaOdontologica.getPacienteConsultado().getIdPaciente());
		ProtocoloPreNatal protocolo = (ProtocoloPreNatal) protocoloPreNatalRepository
				.findById(consultaOdontologica.getProtocoloPertencente().getIdProtocolo());

		if (paciente == null || protocolo == null) {
			throw new IllegalArgumentException("Uma ou mais entidades não foram encontradas.");
		}
		consultaOdontologica.setPacienteConsultado(paciente);
		consultaOdontologica.setProtocoloPertencente(protocolo);
		return (ConsultaOdontologica) consultaOdontologicaRepository.create(consultaOdontologica);
	}

	public ConsultaOdontologica obterConsultaOdontologicaPorId(Long id) {
		return (ConsultaOdontologica) consultaOdontologicaRepository.findById(id);
	}

	public ConsultaOdontologica atualizarConsultaOdontologica(ConsultaOdontologica consultaOdontologica) {
		return (ConsultaOdontologica) consultaOdontologicaRepository.updateById(consultaOdontologica);
	}

	public void deletarConsultaOdontologica(Long id) {
		consultaOdontologicaRepository.delete(id);
	}

	public List<ConsultaOdontologica> obterTodosConsultaOdontologicas() {
		return consultaOdontologicaRepository.findAll();
	}

}
