package model.service;

import java.util.List;

import model.entities.*;
import model.repositories.EnderecoRepository;
import model.repositories.ResidenciasPacienteRepository;

public class ResidenciasPacienteService {

	private ResidenciasPacienteRepository residenciasPacienteRepository;
	private EnderecoRepository enderecoRepository;

	// LOGICAS DE NEGOCIOS NO SERVICE INTERAGEM COM O REPOSITORY
	public ResidenciasPacienteService() {
		this.residenciasPacienteRepository = new ResidenciasPacienteRepository();
		this.enderecoRepository = new EnderecoRepository();

	}

//este bloco de codigo garante que as entidades existem antes de criar uma nova residenciasPaciente
	public ResidenciasPaciente adicionarResidenciasPaciente(ResidenciasPaciente residenciasPaciente) {
		// resgata as entidades relacionadas do banco de dados
		Endereco endereco = (Endereco) enderecoRepository.findById(residenciasPaciente.getEndereco().getIdEndereco());

		if (endereco == null) {
			throw new IllegalArgumentException("Uma ou mais entidades não foram encontradas.");
		}

		residenciasPaciente.setEndereco(endereco);

		return (ResidenciasPaciente) residenciasPacienteRepository.create(residenciasPaciente);
	}

	public ResidenciasPaciente obterResidenciasPacientePorId(Long id) {
		return (ResidenciasPaciente) residenciasPacienteRepository.findById(id);
	}

	public ResidenciasPaciente atualizarResidenciasPaciente(ResidenciasPaciente residenciasPaciente) {
		return (ResidenciasPaciente) residenciasPacienteRepository.updateById(residenciasPaciente);
	}

	public void deletarResidenciasPaciente(Long id) {
		residenciasPacienteRepository.delete(id);
	}

	public List<ResidenciasPaciente> obterTodosResidenciasPacientes() {
		return residenciasPacienteRepository.findAll();
	}
}
