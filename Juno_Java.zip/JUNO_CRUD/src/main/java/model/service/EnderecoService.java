package model.service;

import java.util.List;

import model.entities.*;
import model.repositories.EnderecoRepository;

public class EnderecoService {

	private EnderecoRepository enderecoRepository;

	// LOGICAS DE NEGOCIOS NO SERVICE INTERAGEM COM O REPOSITORY
	public EnderecoService() {
		this.enderecoRepository = new EnderecoRepository();
	}

	public Endereco adicionarEndereco(Endereco endereco) {

		return (Endereco) enderecoRepository.create(endereco);
	}

	public Endereco obterEnderecoPorId(Long id) {
		return (Endereco) enderecoRepository.findById(id);
	}

	public Endereco atualizarEndereco(Endereco endereco) {
		return (Endereco) enderecoRepository.updateById(endereco);
	}

	public void deletarEndereco(Long id) {
		enderecoRepository.delete(id);
	}

	public List<Endereco> obterTodosEnderecos() {
		return enderecoRepository.findAll();
	}
}
