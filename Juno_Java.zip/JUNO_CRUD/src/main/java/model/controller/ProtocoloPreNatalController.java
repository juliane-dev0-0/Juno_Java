package model.controller;

import java.util.List;

import model.entities.ProtocoloPreNatal;
import model.service.ProtocoloPreNatalService;

//INTERAGE COM A VIEW E COM O SERVICE

public class ProtocoloPreNatalController {
	private ProtocoloPreNatalService protocoloPreNatalService;

	public ProtocoloPreNatalController() {
		this.protocoloPreNatalService = new ProtocoloPreNatalService();
	}

	public ProtocoloPreNatal adicionarProtocoloPreNatal(ProtocoloPreNatal protocoloPreNatal) {
		return protocoloPreNatalService.adicionarProtocoloPreNatal(protocoloPreNatal);
	}

	public ProtocoloPreNatal obterProtocoloPreNatalPorId(Long id) {
		return protocoloPreNatalService.obterProtocoloPreNatalPorId(id);
	}

	public ProtocoloPreNatal atualizarProtocoloPreNatal(ProtocoloPreNatal protocoloPreNatal) {
		return protocoloPreNatalService.atualizarProtocoloPreNatal(protocoloPreNatal);
	}

	public void deletarProtocoloPreNatal(Long id) {
		protocoloPreNatalService.deletarProtocoloPreNatal(id);
	}

	public List<ProtocoloPreNatal> obterTodosProtocoloPreNatals() {
		return protocoloPreNatalService.obterTodosProtocoloPreNatals();

	}
}
