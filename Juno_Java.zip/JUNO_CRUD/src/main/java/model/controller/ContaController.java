package model.controller;

import java.util.List;

import model.entities.Conta;
import model.service.ContaService;

//INTERAGE COM A VIEW E COM O SERVICE

public class ContaController {
	private ContaService contaService;

	public ContaController() {
		this.contaService = new ContaService();
	}

	public Conta adicionarConta(Conta conta) {
		return contaService.adicionarConta(conta);
	}

	public Conta obterContaPorId(Long id) {
		return contaService.obterContaPorId(id);
	}

	public Conta atualizarConta(Conta conta) {
		return contaService.atualizarConta(conta);
	}

	public void deletarConta(Long id) {
		contaService.deletarConta(id);
	}

	public List<Conta> obterTodosContas() {
		return contaService.obterTodosContas();

	}

}
