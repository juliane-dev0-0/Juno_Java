package model.controller;

import java.util.List;

import model.entities.Publico;
import model.service.PublicoService;

//INTERAGE COM A VIEW E COM O SERVICE

public class PublicoController {
	private PublicoService publicoService;

	public PublicoController() {
		this.publicoService = new PublicoService();
	}

	public Publico adicionarPublico(Publico publico) {
		return publicoService.adicionarPublico(publico);
	}

	public Publico obterPublicoPorId(Long id) {
		return publicoService.obterPublicoPorId(id);
	}

	public Publico atualizarPublico(Publico publico) {
		return publicoService.atualizarPublico(publico);
	}

	public void deletarPublico(Long id) {
		publicoService.deletarPublico(id);
	}

	public List<Publico> obterTodosPublicos() {
		return publicoService.obterTodosPublicos();

	}
}
