package model.controller;

import java.util.List;

import model.entities.Equipe;
import model.service.EquipeService;

//INTERAGE COM A VIEW E COM O SERVICE

public class EquipeController {
	private EquipeService equipeService;

	public EquipeController() {
		this.equipeService = new EquipeService();
	}

	public Equipe adicionarEquipe(Equipe equipe) {
		return equipeService.adicionarEquipe(equipe);
	}

	public Equipe obterEquipePorId(Long id) {
		return equipeService.obterEquipePorId(id);
	}

	public Equipe atualizarEquipe(Equipe equipe) {
		return equipeService.atualizarEquipe(equipe);
	}

	public void deletarEquipe(Long id) {
		equipeService.deletarEquipe(id);
	}

	public List<Equipe> obterTodosEquipes() {
		return equipeService.obterTodosEquipes();

	}
}
