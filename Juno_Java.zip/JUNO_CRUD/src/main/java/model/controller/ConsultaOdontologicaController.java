package model.controller;

import java.util.List;

import model.entities.ConsultaOdontologica;
import model.service.ConsultaOdontologicaService;

//INTERAGE COM A VIEW E COM O SERVICE

public class ConsultaOdontologicaController {
	private ConsultaOdontologicaService consultaOdontologicaService;

	public ConsultaOdontologicaController() {
		this.consultaOdontologicaService = new ConsultaOdontologicaService();
	}

	public ConsultaOdontologica adicionarConsultaOdontologica(ConsultaOdontologica consultaOdontologica) {
		return consultaOdontologicaService.adicionarConsultaOdontologica(consultaOdontologica);
	}

	public ConsultaOdontologica obterConsultaOdontologicaPorId(Long id) {
		return consultaOdontologicaService.obterConsultaOdontologicaPorId(id);
	}

	public ConsultaOdontologica atualizarConsultaOdontologica(ConsultaOdontologica consultaOdontologica) {
		return consultaOdontologicaService.atualizarConsultaOdontologica(consultaOdontologica);
	}

	public void deletarConsultaOdontologica(Long id) {
		consultaOdontologicaService.deletarConsultaOdontologica(id);
	}

	public List<ConsultaOdontologica> obterTodosConsultaOdontologicas() {
		return consultaOdontologicaService.obterTodosConsultaOdontologicas();

	}
}
