package model.controller;

import java.util.List;

import model.entities.ProtocolosEncerrados;
import model.service.ProtocolosEncerradosService;

//INTERAGE COM A VIEW E COM O SERVICE

public class ProtocolosEncerradosController {
	private ProtocolosEncerradosService protocolosEncerradosService;

	public ProtocolosEncerradosController() {
		this.protocolosEncerradosService = new ProtocolosEncerradosService();
	}

	public ProtocolosEncerrados adicionarProtocolosEncerrados(ProtocolosEncerrados protocolosEncerrados) {
		return protocolosEncerradosService.adicionarProtocolosEncerrados(protocolosEncerrados);
	}

	public ProtocolosEncerrados obterProtocolosEncerradosPorId(Long id) {
		return protocolosEncerradosService.obterProtocolosEncerradosPorId(id);
	}

	public ProtocolosEncerrados atualizarProtocolosEncerrados(ProtocolosEncerrados protocolosEncerrados) {
		return protocolosEncerradosService.atualizarProtocolosEncerrados(protocolosEncerrados);
	}

	public void deletarProtocolosEncerrados(Long id) {
		protocolosEncerradosService.deletarProtocolosEncerrados(id);
	}

	public List<ProtocolosEncerrados> obterTodosProtocolosEncerradoss() {
		return protocolosEncerradosService.obterTodosProtocolosEncerradoss();

	}
}
