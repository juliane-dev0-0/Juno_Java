package model.controller;

import java.util.List;

import model.entities.Usuario;
//INTERAGE COM A VIEW E COM O SERVICE
import model.service.UsuarioService;

public class UsuarioController {
	private UsuarioService usuarioService;

	public UsuarioController() {
		this.usuarioService = new UsuarioService();
	}

	public Usuario adicionarUsuario(Usuario usuario) {
		return usuarioService.adicionarUsuario(usuario);
	}

	public Usuario obterUsuarioPorId(Long id) {
		return usuarioService.obterUsuarioPorId(id);
	}

	public Usuario atualizarUsuario(Usuario usuario) {
		return usuarioService.atualizarUsuario(usuario);
	}

	public void deletarUsuario(Long id) {
		usuarioService.deletarUsuario(id);
	}

	public List<Usuario> obterTodosUsuarios() {
		return usuarioService.obterTodosUsuarios();

	}

	public Usuario adicionarUsuario(String nome, String senha, String email, String cpf, String nivel) {
		Usuario usuario = new Usuario();
		usuario.setNome(nome);
		usuario.setSenha(senha);
		usuario.setEmail(email);
		usuario.setCpf(cpf);
		usuario.setNivel(nivel);

		return usuarioService.adicionarUsuario(usuario);
	}
}
