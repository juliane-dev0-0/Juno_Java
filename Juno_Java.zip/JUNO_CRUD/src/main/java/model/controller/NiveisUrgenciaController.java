package model.controller;

import java.util.List;

import model.entities.NiveisUrgencia;
import model.service.NiveisUrgenciaService;

//INTERAGE COM A VIEW E COM O SERVICE

public class NiveisUrgenciaController {
	private NiveisUrgenciaService niveisUrgenciaService;

	public NiveisUrgenciaController() {
		this.niveisUrgenciaService = new NiveisUrgenciaService();
	}

	public NiveisUrgencia adicionarNiveisUrgencia(NiveisUrgencia niveisUrgencia) {
		return niveisUrgenciaService.adicionarNiveisUrgencia(niveisUrgencia);
	}

	public NiveisUrgencia obterNiveisUrgenciaPorId(Long id) {
		return niveisUrgenciaService.obterNiveisUrgenciaPorId(id);
	}

	public NiveisUrgencia atualizarNiveisUrgencia(NiveisUrgencia niveisUrgencia) {
		return niveisUrgenciaService.atualizarNiveisUrgencia(niveisUrgencia);
	}

	public void deletarNiveisUrgencia(Long id) {
		niveisUrgenciaService.deletarNiveisUrgencia(id);
	}

	public List<NiveisUrgencia> obterTodosNiveisUrgencias() {
		return niveisUrgenciaService.obterTodosNiveisUrgencias();

	}
}
