package model.controller;

import java.util.List;

import model.entities.ContaRole;
//INTERAGE COM A VIEW E COM O SERVICE
import model.service.ContaRoleService;

public class ContaRoleController {
	private ContaRoleService contaRoleService;

	public ContaRoleController() {
		this.contaRoleService = new ContaRoleService();
	}

	public ContaRole adicionarContaRole(ContaRole contaRole) {
		return contaRoleService.adicionarContaRole(contaRole);
	}

	public ContaRole obterContaRolePorId(Long id) {
		return contaRoleService.obterContaRolePorId(id);
	}

	public ContaRole atualizarContaRole(ContaRole contaRole) {
		return contaRoleService.atualizarContaRole(contaRole);
	}

	public void deletarContaRole(Long id) {
		contaRoleService.deletarContaRole(id);
	}

	public List<ContaRole> obterTodosContaRoles() {
		return contaRoleService.obterTodosContaRoles();

	}
}
