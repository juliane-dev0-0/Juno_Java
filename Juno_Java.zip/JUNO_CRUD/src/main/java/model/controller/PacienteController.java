package model.controller;

import java.util.List;

import model.entities.Paciente;
import model.service.PacienteService;

//INTERAGE COM A VIEW E COM O SERVICE

public class PacienteController {
	private PacienteService pacienteService;

	public PacienteController() {
		this.pacienteService = new PacienteService();
	}

	public Paciente adicionarPaciente(Paciente paciente) {
		return pacienteService.adicionarPaciente(paciente);
	}

	public Paciente obterPacientePorId(Long id) {
		return pacienteService.obterPacientePorId(id);
	}

	public Paciente obterPacientePorNome(String nome) {
		return pacienteService.obterPacientePorNome(nome);
	}

	public Paciente atualizarPaciente(Paciente paciente) {
		return pacienteService.atualizarPaciente(paciente);
	}

	public void deletarPaciente(Long id) {
		pacienteService.deletarPaciente(id);
	}

	public List<Paciente> obterTodosPacientes() {
		return pacienteService.obterTodosPacientes();

	}
}
