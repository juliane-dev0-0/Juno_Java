package model.controller;

import java.util.List;

import model.entities.Endereco;
import model.service.EnderecoService;

//INTERAGE COM A VIEW E COM O SERVICE

public class EnderecoController {
	private EnderecoService enderecoService;

	public EnderecoController() {
		this.enderecoService = new EnderecoService();
	}

	public Endereco adicionarEndereco(Endereco endereco) {
		return enderecoService.adicionarEndereco(endereco);
	}

	public Endereco obterEnderecoPorId(Long id) {
		return enderecoService.obterEnderecoPorId(id);
	}

	public Endereco atualizarEndereco(Endereco endereco) {
		return enderecoService.atualizarEndereco(endereco);
	}

	public void deletarEndereco(Long id) {
		enderecoService.deletarEndereco(id);
	}

	public List<Endereco> obterTodosEnderecos() {
		return enderecoService.obterTodosEnderecos();

	}
}
