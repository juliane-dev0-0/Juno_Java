package model.controller;

import java.util.List;

import model.entities.TesteRapido;
import model.service.TesteRapidoService;

//INTERAGE COM A VIEW E COM O SERVICE

public class TesteRapidoController {
	private TesteRapidoService testeRapidoService;

	public TesteRapidoController() {
		this.testeRapidoService = new TesteRapidoService();
	}

	public TesteRapido adicionarTesteRapido(TesteRapido testeRapido) {
		return testeRapidoService.adicionarTesteRapido(testeRapido);
	}

	public TesteRapido obterTesteRapidoPorId(Long id) {
		return testeRapidoService.obterTesteRapidoPorId(id);
	}

	public TesteRapido atualizarTesteRapido(TesteRapido testeRapido) {
		return testeRapidoService.atualizarTesteRapido(testeRapido);
	}

	public void deletarTesteRapido(Long id) {
		testeRapidoService.deletarTesteRapido(id);
	}

	public List<TesteRapido> obterTodosTesteRapidos() {
		return testeRapidoService.obterTodosTesteRapidos();

	}
}
