package model.controller;

import java.util.List;

import model.entities.ResidenciasPaciente;
import model.service.ResidenciasPacienteService;

//INTERAGE COM A VIEW E COM O SERVICE

public class ResidenciasPacienteController {
	private ResidenciasPacienteService residenciasPacienteService;

	public ResidenciasPacienteController() {
		this.residenciasPacienteService = new ResidenciasPacienteService();
	}

	public ResidenciasPaciente adicionarResidenciasPaciente(ResidenciasPaciente residenciasPaciente) {
		return residenciasPacienteService.adicionarResidenciasPaciente(residenciasPaciente);
	}

	public ResidenciasPaciente obterResidenciasPacientePorId(Long id) {
		return residenciasPacienteService.obterResidenciasPacientePorId(id);
	}

	public ResidenciasPaciente atualizarResidenciasPaciente(ResidenciasPaciente residenciasPaciente) {
		return residenciasPacienteService.atualizarResidenciasPaciente(residenciasPaciente);
	}

	public void deletarResidenciasPaciente(Long id) {
		residenciasPacienteService.deletarResidenciasPaciente(id);
	}

	public List<ResidenciasPaciente> obterTodosResidenciasPacientes() {
		return residenciasPacienteService.obterTodosResidenciasPacientes();

	}
}
